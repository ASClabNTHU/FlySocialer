recordDuration=15;
dataFolder='H:\����\0909\0909_VT30604_7days_(M)(M)(F)(F)_result4';
preInteractAnalysis=0;preInteractDurationTotalAnalysis=0;
totalInteractAnalysis=zeros(recordDuration,1);
totalInteractDurationTotalAnalysis=zeros(recordDuration,1);
for a=1:recordDuration
load ([dataFolder '\interact_analysis'  num2str(a)])
load ([dataFolder '\interact_durationTotal_analysis'  num2str(a)])

       
end
%%1
        tempInteractAnalysis=sum(sum(interact_analysis1));
        
        tempInteractDurationTotalAnalysis=sum(sum(interact_durationTotal_analysis1));
        totalInteractAnalysis(1,1)=tempInteractAnalysis-preInteractAnalysis;
        totalInteractDurationTotalAnalysis(1,1)=tempInteractDurationTotalAnalysis-preInteractDurationTotalAnalysis;
        
        preInteractAnalysis=tempInteractAnalysis;
        preInteractDurationTotalAnalysis=tempInteractDurationTotalAnalysis;
        %%%2
        
        tempInteractAnalysis=sum(sum(interact_analysis2));
        
        tempInteractDurationTotalAnalysis=sum(sum(interact_durationTotal_analysis2));
        totalInteractAnalysis(2,1)=tempInteractAnalysis-preInteractAnalysis;
        totalInteractDurationTotalAnalysis(2,1)=tempInteractDurationTotalAnalysis-preInteractDurationTotalAnalysis;
        
        preInteractAnalysis=tempInteractAnalysis;
        preInteractDurationTotalAnalysis=tempInteractDurationTotalAnalysis;
        %%%3
        
        tempInteractAnalysis=sum(sum(interact_analysis3));
        
        tempInteractDurationTotalAnalysis=sum(sum(interact_durationTotal_analysis3));
        totalInteractAnalysis(3,1)=tempInteractAnalysis-preInteractAnalysis;
        totalInteractDurationTotalAnalysis(3,1)=tempInteractDurationTotalAnalysis-preInteractDurationTotalAnalysis;
        
        preInteractAnalysis=tempInteractAnalysis;
        preInteractDurationTotalAnalysis=tempInteractDurationTotalAnalysis;
        %%%4
        
        tempInteractAnalysis=sum(sum(interact_analysis4));
        
        tempInteractDurationTotalAnalysis=sum(sum(interact_durationTotal_analysis4));
        totalInteractAnalysis(4,1)=tempInteractAnalysis-preInteractAnalysis;
        totalInteractDurationTotalAnalysis(4,1)=tempInteractDurationTotalAnalysis-preInteractDurationTotalAnalysis;
        
        preInteractAnalysis=tempInteractAnalysis;
        preInteractDurationTotalAnalysis=tempInteractDurationTotalAnalysis;
        %%%5
        
        tempInteractAnalysis=sum(sum(interact_analysis5));
        
        tempInteractDurationTotalAnalysis=sum(sum(interact_durationTotal_analysis5));
        totalInteractAnalysis(5,1)=tempInteractAnalysis-preInteractAnalysis;
        totalInteractDurationTotalAnalysis(5,1)=tempInteractDurationTotalAnalysis-preInteractDurationTotalAnalysis;
        
        preInteractAnalysis=tempInteractAnalysis;
        preInteractDurationTotalAnalysis=tempInteractDurationTotalAnalysis;
        %%%6
        
        tempInteractAnalysis=sum(sum(interact_analysis6));
        
        tempInteractDurationTotalAnalysis=sum(sum(interact_durationTotal_analysis6));
        totalInteractAnalysis(6,1)=tempInteractAnalysis-preInteractAnalysis;
        totalInteractDurationTotalAnalysis(6,1)=tempInteractDurationTotalAnalysis-preInteractDurationTotalAnalysis;
        
        preInteractAnalysis=tempInteractAnalysis;
        preInteractDurationTotalAnalysis=tempInteractDurationTotalAnalysis;
        %%%7
        
        tempInteractAnalysis=sum(sum(interact_analysis7));
        
        tempInteractDurationTotalAnalysis=sum(sum(interact_durationTotal_analysis7));
        totalInteractAnalysis(7,1)=tempInteractAnalysis-preInteractAnalysis;
        totalInteractDurationTotalAnalysis(7,1)=tempInteractDurationTotalAnalysis-preInteractDurationTotalAnalysis;
        
        preInteractAnalysis=tempInteractAnalysis;
        preInteractDurationTotalAnalysis=tempInteractDurationTotalAnalysis;
        %%%8
        
        tempInteractAnalysis=sum(sum(interact_analysis8));
        
        tempInteractDurationTotalAnalysis=sum(sum(interact_durationTotal_analysis8));
        totalInteractAnalysis(8,1)=tempInteractAnalysis-preInteractAnalysis;
        totalInteractDurationTotalAnalysis(8,1)=tempInteractDurationTotalAnalysis-preInteractDurationTotalAnalysis;
        
        preInteractAnalysis=tempInteractAnalysis;
        preInteractDurationTotalAnalysis=tempInteractDurationTotalAnalysis;
        %%%9
        
        tempInteractAnalysis=sum(sum(interact_analysis9));
        
        tempInteractDurationTotalAnalysis=sum(sum(interact_durationTotal_analysis9));
        totalInteractAnalysis(9,1)=tempInteractAnalysis-preInteractAnalysis;
        totalInteractDurationTotalAnalysis(9,1)=tempInteractDurationTotalAnalysis-preInteractDurationTotalAnalysis;
        
        preInteractAnalysis=tempInteractAnalysis;
        preInteractDurationTotalAnalysis=tempInteractDurationTotalAnalysis;
        %%%10
        
        tempInteractAnalysis=sum(sum(interact_analysis10));
        
        tempInteractDurationTotalAnalysis=sum(sum(interact_durationTotal_analysis10));
        totalInteractAnalysis(10,1)=tempInteractAnalysis-preInteractAnalysis;
        totalInteractDurationTotalAnalysis(10,1)=tempInteractDurationTotalAnalysis-preInteractDurationTotalAnalysis;
        
        preInteractAnalysis=tempInteractAnalysis;
        preInteractDurationTotalAnalysis=tempInteractDurationTotalAnalysis;
        %%%11
        
        tempInteractAnalysis=sum(sum(interact_analysis11));
        
        tempInteractDurationTotalAnalysis=sum(sum(interact_durationTotal_analysis11));
        totalInteractAnalysis(11,1)=tempInteractAnalysis-preInteractAnalysis;
        totalInteractDurationTotalAnalysis(11,1)=tempInteractDurationTotalAnalysis-preInteractDurationTotalAnalysis;
        
        preInteractAnalysis=tempInteractAnalysis;
        preInteractDurationTotalAnalysis=tempInteractDurationTotalAnalysis;
        %%%
        
        tempInteractAnalysis=sum(sum(interact_analysis12));
        
        tempInteractDurationTotalAnalysis=sum(sum(interact_durationTotal_analysis12));
        totalInteractAnalysis(12,1)=tempInteractAnalysis-preInteractAnalysis;
        totalInteractDurationTotalAnalysis(12,1)=tempInteractDurationTotalAnalysis-preInteractDurationTotalAnalysis;
        
        preInteractAnalysis=tempInteractAnalysis;
        preInteractDurationTotalAnalysis=tempInteractDurationTotalAnalysis;
        %%%
        
        tempInteractAnalysis=sum(sum(interact_analysis13));
        
        tempInteractDurationTotalAnalysis=sum(sum(interact_durationTotal_analysis13));
        totalInteractAnalysis(13,1)=tempInteractAnalysis-preInteractAnalysis;
        totalInteractDurationTotalAnalysis(13,1)=tempInteractDurationTotalAnalysis-preInteractDurationTotalAnalysis;
        
        preInteractAnalysis=tempInteractAnalysis;
        preInteractDurationTotalAnalysis=tempInteractDurationTotalAnalysis;
        %%%
        
        tempInteractAnalysis=sum(sum(interact_analysis14));
        
        tempInteractDurationTotalAnalysis=sum(sum(interact_durationTotal_analysis14));
        totalInteractAnalysis(14,1)=tempInteractAnalysis-preInteractAnalysis;
        totalInteractDurationTotalAnalysis(14,1)=tempInteractDurationTotalAnalysis-preInteractDurationTotalAnalysis;
        
        preInteractAnalysis=tempInteractAnalysis;
        preInteractDurationTotalAnalysis=tempInteractDurationTotalAnalysis;
          %%%
        
        tempInteractAnalysis=sum(sum(interact_analysis15));
        
        tempInteractDurationTotalAnalysis=sum(sum(interact_durationTotal_analysis15));
        totalInteractAnalysis(15,1)=tempInteractAnalysis-preInteractAnalysis;
        totalInteractDurationTotalAnalysis(15,1)=tempInteractDurationTotalAnalysis-preInteractDurationTotalAnalysis;
        
        preInteractAnalysis=tempInteractAnalysis;
        preInteractDurationTotalAnalysis=tempInteractDurationTotalAnalysis;
        
        xlswrite([dataFolder '\totalInteractAnalysis.xlsx'],totalInteractAnalysis);
xlswrite([dataFolder '\totalInteractDurationTotalAnalysis.xlsx'],totalInteractDurationTotalAnalysis);