close all
clear all
savePath='C:\20200823';
imageFolder='C:\20200823';
ArenaNum=3;
%imageFolder='Z:\Fly-Tracker\Flytracker_result2\WT model-Male';
mkdir(savePath);
img_assembly = dir(fullfile(imageFolder,'\*.jpg'));

for p = 1:length(img_assembly)
    
    build_img_names{p,1} = img_assembly(p).name;    % �x�s�C�i�v���W�٪�cell�x�}
        
end

[sorted_name,INDEX] = sort_nat(build_img_names);    % �ϥ�nature sort

nFrames = length(img_assembly);

for i = 1 : nFrames
a = imread(fullfile(imageFolder,sorted_name{i}));
figure, imshow(a); 
[centers, radii] = imfindcircles(rgb2gray(a),[460 500], 'ObjectPolarity','bright','Sensitivity',0.98); hold on
DD = zeros(1024,1024);
h = viscircles(centers,radii);
[gg yy]=size(radii);%stop here then run program, if ok then continue
if gg <ArenaNum
    [centers, radii] = imfindcircles(rgb2gray(a),[460 490], 'ObjectPolarity','bright','Sensitivity',0.99); hold off
    figure, imshow(a); 
    h = viscircles(centers,radii);
end
%a=imread('back_0831_20male_7days_(VT26665)(VT44966)(VT9843)(VT9843).jpg');
a=rgb2gray(a);
for count = 1:ArenaNum
for p = 1:1024
    for q = 1:1024
   
      
       
   if norm([p q]-[centers(count,2), centers(count,1)])<radii(count);
     
         %if norm([p q]-[1015 1003])<1020 for 10/23
      %if norm([p q]-[1570 665])<430 %3D
          DD(p,q)=1; 
       end
        
    end
end

test = a.*uint8(DD);
%figure,imshow(test);

interest_circle = DD;
if (centers(count,1)>1000)
    if (centers(count,2)>1000)
        count2=4;
    else
        count2=2;
    end
else
    if (centers(count,2)>1000)
        count2=3;
    else
        count2=1;
    end
end
C = strsplit(sorted_name{i},'.');
save([ savePath '\'  C{1, 1} '_interest_circle_' num2str(count2) '.mat'],'interest_circle'); 
DD = zeros(1024,1024);
end
end
%figure,imshow(im1);hold on;circles(525,1530,500,'edgecolor',[.5 .2 .9],'linewidth',2, 'facecolor','none')