clear all
close all
imageFolder='C:\CantonS_single vs group\20230801';

savePath='C:\CantonS_single vs group\20230801';
mkdir(savePath)
backBatchMountain
