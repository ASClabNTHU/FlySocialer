a=imread('C:\CantonS_single vs group\20230718B\_0718_2_CantonS_0_CantonS\Image11238.jpg');
a=rgb2gray(a);
%imshow(get_rid_of_rough);hold on
imshow(a);hold on
circles(515,1545,475,'edgecolor',[.5 .2 .9],'edgecolor','y','facecolor','none')
%heat plate circles(970,1045,470)
%two color light plate circles(900,1055,400)