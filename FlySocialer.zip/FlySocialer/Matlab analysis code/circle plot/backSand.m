
criteria_n_of_ob = 20;    %�@�v�����G�Ǽƶq
img_assembly = dir(fullfile(img_dir,'\*.jpg'));
se = strel('disk',3);  
cr = [0 1 0;1 1 1;0 1 0];                                             % morphological processing ��(cr,sq�i�H�̻ݨD���)
sq = ones(3,3);
for p = 1:length(img_assembly)
    
    build_img_names{p,1} = img_assembly(p).name;    % �x�s�C�i�v���W�٪�cell�x�}
        
end
[sorted_name,INDEX] = sort_nat(build_img_names);    % �ϥ�nature sort

nFrames = length(img_assembly);
count=0;
back = imread(fullfile(img_dir,sorted_name{1}));
%back = imread('back_0804sound_20male_6days_(dumb)(44966dumb)(49246dumb)(57244dumb)_2.jpg');
for i=1:10:nFrames
    
     im2 = imread(fullfile(img_dir,sorted_name{i}));
     back=max(back,im2);
     %back=back/2;
end
figure,imshow(uint8(back))