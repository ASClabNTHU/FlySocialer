d = dir(imageFolder);
isub = [d(:).isdir]; %# returns logical vector
nameFolds = {d(isub).name}';

for i = 3:length(nameFolds)
    
    tempName=nameFolds{i};    % �x�s�C�i�v���W�٪�cell�x�}
    img_dir = [imageFolder  '\' tempName];
    backSand;
    imwrite(back,[savePath '\back'  tempName '.jpg']);
%     [token, remain] = strsplit(tempName,'_');
%     for i = 2:length(token)
%         out = strcmp( knownName,token{i});
%         if max(out)==0
%             knownName{length(knownName)+1}=token{i};
%             nameCount(length(nameCount)+1)=1;
%         else
%             nameCount=nameCount+out;
%         end
%     end
   
    
   
        
end