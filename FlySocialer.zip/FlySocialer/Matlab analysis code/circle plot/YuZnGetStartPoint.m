%%
p = genpath(imageFolder);% 獲得資料夾data下所有子檔案的路徑，這些路徑存在字串p中，以';'分割
length_p = size(p,2);%字串p的長度
path = {};%建立一個單元陣列，陣列的每個單元中包含一個目錄
temp = [];
for i = 1:length_p %尋找分割符';'，一旦找到，則將路徑temp寫入path陣列中
    if p(i) ~= ';'
        temp = [temp p(i)];
    else 
        %temp = [temp '\']; %在路徑的最後加入 '\'
        path = [path ; temp];
        temp = [];
    end
end  
clear p length_p temp;
%%
file_num = size(path,1);% 子資料夾的個數
for i = 2:file_num
    file_path =  path{i}; % 影象資料夾路徑
    for j = 2:4 %要分析的位置
        back=imread([file_path '\image0.jpg']);
        imshow(back);
        criteria_n_of_ob=10;
        previous_centroid2 = ginput(criteria_n_of_ob);
        save([file_path(1:numel(path{1})+1),'point',int2str(j),file_path(numel(path{1})+2:end),'.mat'] ,'previous_centroid2');
    end
end