%% 拍攝面積設定
M=2048;N=2048; %%全部面積的設定
%M=2048;N=1024; %%一半面積的設定
%M=1820;N=1820; %%TEST
%%
DD = zeros(M,N); 
a=imread('C:\IR light plate test 28mW\_1006_test_1\Image0.jpg');
a=rgb2gray(a);
for p = 1:M
    for q = 1:N
   
       
       if norm([p q]-[1800 1800])<10
     
          DD(p,q)=1; 
       end
        
    end
end
test = a.*uint8(DD);
figure,imshow(test);
    
interest_circle = DD;
save('C:\IR light plate test 28mW\back_1006_test_1_interest_circle_3.mat','interest_circle');

% 2 arena if norm([p q]-[540 1510])<475
% 1 big arena if norm([p q]-[910 960])<640