img_assembly = dir(fullfile(img_dir,'\*.jpg'));
se = strel('disk',3);  
cr = [0 1 0;1 1 1;0 1 0];                                             % morphological processing 用(cr,sq可以依需求選用)
sq = ones(3,3);
for p = 1:length(img_assembly)
    
    build_img_names{p,1} = img_assembly(p).name;    % 儲存每張影像名稱的cell矩陣
        
end
[sorted_name,INDEX] = sort_nat(build_img_names);    % 使用nature sort

nFrames = length(img_assembly);
count=0;
back = imread(fullfile(img_dir,sorted_name{1}));
%back = imread('back_0804sound_20male_6days_(dumb)(44966dumb)(49246dumb)(57244dumb)_2.jpg');
for i=1:500:5000
    
     im2 = imread(fullfile(img_dir,sorted_name{i}));
     back=max(back,im2);
     %back=back/2;
end
figure,imshow(uint8(back))