%% 拍攝面積設定
%M=2048;N=2048; %%全部面積的設定
M=2048;N=1024; %%一半面積的設定
%M=1820;N=1820; %%TEST
%%
DD = zeros(M,N); 
a=imread('C:\CantonS_single vs group\20230718B\_0718_2_CantonS_0_CantonS\Image11238.jpg');
a=rgb2gray(a);
for p = 1:M
    for q = 1:N
   
       
       if norm([p q]-[1545 515])<475
     
          DD(p,q)=1; 
       end
        
    end
end
test = a.*uint8(DD);
figure,imshow(test);
    
interest_circle = DD;
save('C:\CantonS_single vs group\20230718B\back_0718_2_CantonS_0_CantonS_interest_circle_3.mat','interest_circle');

% 2 arena if norm([p q]-[540 1510])<475
% heat plate 1 big arena if norm([p q]-[1045 1030])<520
% 2 color light plate 1 big arena if norm([p q]-[1045 1030])<520