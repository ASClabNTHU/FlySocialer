%%
% clear all
% img_dir = 'E:\YuZn0427\_0427_1_w1118_2u_CS';%�Ϥ���m
% video_name='E:\YuZn0427\_0427_1_w1118_2u_CS';%�v���x�s��m�M�ɦW
frameQ=20;
nFrames=600*frameQ;%����*մ��
save_video =1; 
img_assembly = dir(fullfile(img_dir,'\*.jpg'));

for p = 1:length(img_assembly)
    
    build_img_names{p,1} = img_assembly(p).name;    % �x�s�C�i�v���W�٪�cell�x�}
        
end

[sorted_name,INDEX] = sort_nat(build_img_names);    % �ϥ�nature sort


if save_video ==1
    movFile = VideoWriter(video_name,'MPEG-4');
    set(movFile,'FrameRate',frameQ,'Quality',100);
    open(movFile);
end
for i = 1 :nFrames
     source = imread(fullfile(img_dir,sorted_name{i}));
     imshow(source);
      F=getframe(gca);
      writeVideo(movFile,F);
end
if save_video ==1    
    close(movFile);
end

load handel
sound(y,Fs)
