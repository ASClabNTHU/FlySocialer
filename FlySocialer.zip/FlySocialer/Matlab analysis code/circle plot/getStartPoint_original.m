save_dir='C:\CantonS_single vs group\20230801';
back=imread('C:\CantonS_single vs group\20230801\_0801_5_CantonS_0_CantonS\Image0.jpg');
imshow(back);
criteria_n_of_ob=10; %���簦��
previous_centroid2 = ginput(criteria_n_of_ob);
save([ save_dir '\point1_0801_5_CantonS_0_CantonS.mat'],'previous_centroid2');
%previous_centroid2 = ginput(cri9*8teria_n_of_ob);
%save([ save_dir '\point3_0320_5_group_0_single.mat'],'previous_centroid2');
previous_centroid2 = ginput(criteria_n_of_ob);
save([ save_dir '\point3_0801_5_CantonS_0_CantonS.mat'],'previous_centroid2');