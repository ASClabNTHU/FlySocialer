function [GROUPPlot]=groupPlotClusteringFunction(dataX,picAddress,experimentPeriod)
pad=ones(experimentPeriod,1);
Bottom=(dataX);
GROUPPlot=zeros(experimentPeriod,10);
i=1;
[row, col] = find(isnan(Bottom((i-1)*experimentPeriod+1:experimentPeriod*i,:)));
emptySelf=mode(col);
for count=1:10
    if count~=emptySelf
        temp=Bottom((i-1)*experimentPeriod+1:experimentPeriod*i,count);
        temp(isnan(temp))=0;
        for count2=1:experimentPeriod
            temp2=temp;
            temp2(count2)=20;
            [Idx,D(count2)] = dsearchn(temp2,temp(count2));
            
        end
        idx=find( D>0.2);
        temp(idx)=nan;
        temp3 = cat(2,temp,pad);
        try
        [idx,groupCentroid]=kmeans(temp3,2);
        catch
            continue;
        end
        if abs(groupCentroid(1)-groupCentroid(2))<0.2
            idx(idx==1)=2;
        else
            elementNumber1=sum(idx==1);
            if elementNumber1<3
                idx(idx==1)=nan;
            end
            elementNumber1=sum(idx==2);
            if elementNumber1<3
                idx(idx==2)=nan;
            end
        end
        C = unique(idx);
        B = C(~isnan(C));
        if isempty(B)==0
            centroid=median(temp(idx==B));
            GROUPPlot((i-1)*experimentPeriod+find(temp>(centroid-0.2)&(temp<centroid+0.2)),count)=1;
        end
    end
end
b=imread(picAddress);
figure,imshow(b)
hold on
BottomRemoveNan=Bottom;
BottomRemoveNan(isnan(BottomRemoveNan))=0;
for yy=1:10
    if sum(GROUPPlot(:,yy))>2
        standard= median(BottomRemoveNan(GROUPPlot(:,yy)>0,yy));
        for xx=1:experimentPeriod
            if GROUPPlot(xx,yy)==1
                if standard<0.33
                    if experimentPeriod == 5
                    plot (((yy-1)*2+1)*30.5+115,((xx-1)*2+1)*53.5+50,'rx')
                    else
                        plot (((yy-1)*2+1)*30.5+115,((xx-1)*2+1)*66.5+50,'rx')
                    end
                else
                    if standard>0.66
                        if experimentPeriod == 5
                        plot (((yy-1)*2+1)*30.5+115,((xx-1)*2+1)*53.5+50,'bo')
                        else
                        plot (((yy-1)*2+1)*30.5+115,((xx-1)*2+1)*66.5+50,'bo')
                    end
                    else
                        if experimentPeriod == 5
                        plot (((yy-1)*2+1)*30.5+115,((xx-1)*2+1)*53.5+50,'g^')
                        else
                        plot (((yy-1)*2+1)*30.5+115,((xx-1)*2+1)*66.5+50,'g^')
                    end
                    end
                end
            end
        end
    end
end
hold off

