clear all
close all
experimentPeriod=5;%����Ѽ�Fake3605Single4
Analy_dir= strings(experimentPeriod,1);
Analy_dir(1) = "C:\Users\BRC\Desktop\w1118 group feeding 20220810\_0810_1_3605_0_3605_result3";
Analy_dir(2) = "C:\Users\BRC\Desktop\w1118 group feeding 20220810\_0810_2_3605_0_3605_result3";
Analy_dir(3) = "C:\Users\BRC\Desktop\w1118 group feeding 20220810\_0810_3_3605_0_3605_result3";
Analy_dir(4) = "C:\Users\BRC\Desktop\w1118 group feeding 20220810\_0810_4_3605_0_3605_result3";
Analy_dir(5) = "C:\Users\BRC\Desktop\w1118 group feeding 20220810\_0810_5_3605_0_3605_result3";
%Analy_dir(6) = "C:\20220805B\_0805_6_3605_0_0_result3";

result_dir = 'C:\Users\BRC\Desktop\w1118 group feeding 20220810\TEST'; 
mkdir(result_dir);
criteria_n_of_ob=10;%����
recordDuration=10;%���R�ɶ�(����)
SingleDistanceThreshold=7*19.5;%���s�Z��7mm*19.5pixel
topNumber=10;
bottomNumber=0;
%%
%socialDistancePlotProcessMount;
%SocialInteractPlotProcessMount;
%SocialInteractDurationPlotProcessMount;
%SocialAverageDurationPlotProcessMount;
%velocityBatch
passiveSocialInteractPlotProcessMount
passiveSocialInteractDurationPlotProcessMount