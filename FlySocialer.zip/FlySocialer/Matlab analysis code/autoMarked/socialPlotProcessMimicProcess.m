clear all
close all
experimentPeriod=5;%����Ѽ�
Analy_dir= strings(experimentPeriod,1);
BatchSampleStart=1;
BatchSamplePairs=12;
BatchDir="C:\Matlab analysis code\Fake\FakeSample";
for batchCount=0:BatchSamplePairs-1
Analy_dir(1) = append(BatchDir, "\fake" ,num2str(BatchSampleStart+batchCount*experimentPeriod), "_result1");
Analy_dir(2) = append(BatchDir, "\fake" ,num2str(BatchSampleStart+batchCount*experimentPeriod+1), "_result1");
Analy_dir(3) = append(BatchDir, "\fake" ,num2str(BatchSampleStart+batchCount*experimentPeriod+2), "_result1");
Analy_dir(4) = append(BatchDir, "\fake" ,num2str(BatchSampleStart+batchCount*experimentPeriod+3), "_result1");
Analy_dir(5) = append(BatchDir, "\fake" ,num2str(BatchSampleStart+batchCount*experimentPeriod+4), "_result1");
%Analy_dir(6) = "C:\ANALYSIS\_0728_6_3605_0_3605_result3";

result_dir = ['C:\ANALYSIS\analysis_result_Fake' num2str(BatchSampleStart+batchCount*experimentPeriod) '-Fake' num2str(BatchSampleStart+batchCount*experimentPeriod+4)]; 
mkdir(result_dir);
criteria_n_of_ob=10;%����
recordDuration=10;%���R�ɶ�(����)
groupDistanceThreshold=7*19.5;%���s�Z��7mm*19.5pixel
topNumber=5;
bottomNumber=5;
%%
%socialDistancePlotProcessMount;
SocialInteractPlotProcessMount;
SocialInteractDurationPlotProcessMount;
SocialAverageDurationPlotProcessMount;
end