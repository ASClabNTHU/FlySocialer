sumGroupAnaysisMinSeparate=zeros(criteria_n_of_ob,1);
for i=1:experimentPeriod
    
        dataX= [ convertStringsToChars(Analy_dir(i)) '\groupAnaysisTotal_' num2str(groupDefinition) 'up.xlsx'];
        groupAnaysisMinSeparate=xlsread (dataX);
        sumGroupAnaysisMinSeparate=groupAnaysisMinSeparate+sumGroupAnaysisMinSeparate;
   
end
[FlyInGroupDurationSort,SortIndex]=sort(sum(sumGroupAnaysisMinSeparate,2),'descend'); %�p���h~��
%{
for i=1:experimentPeriod
    for count = 1:recordDuration
        dataX= [ convertStringsToChars(Analy_dir(i)) '\groupAnaysisMinSeparate\groupAnaysisMinSeparate_' num2str(groupDefinition) 'up_in the ' num2str(count) ' minute.xlsx'];
        groupAnaysisMinSeparate=xlsread (dataX);
        sumGroupAnaysisMinSeparate=groupAnaysisMinSeparate+sumGroupAnaysisMinSeparate;
    end
end
[FlyInGroupDurationSort,SortIndex]=sort(sumGroupAnaysisMinSeparate,'descend'); %�p���h~��
%}
%%
%read array

for i = 1:experimentPeriod
        dataX= [ convertStringsToChars(Analy_dir(i)) '\groupAnaysisTotal_' num2str(groupDefinition) 'up.xlsx'];
        flyInGroupDurationRead(:,:,i)=xlsread (dataX);
end
%%
if topNumber>0
    for i = 1:topNumber
        for count = 1:experimentPeriod
            totalGroupTop((i-1)*experimentPeriod+count,:)=flyInGroupDurationRead(SortIndex(i),:,count);
            totalGroupTop((i-1)*experimentPeriod+count,SortIndex(i))=nan;%�����ۤv
            totalGroupNormalizedTop((i-1)*experimentPeriod+count,:)=(totalGroupTop((i-1)*experimentPeriod+count,:)-min(totalGroupTop((i-1)*experimentPeriod+count,:)))./(max(totalGroupTop((i-1)*experimentPeriod+count,:))-min(totalGroupTop((i-1)*experimentPeriod+count,:)));
        end
        close all
        totalGroupNormalizedTopInverse=1-totalGroupNormalizedTop;
        
        heatmap(totalGroupNormalizedTopInverse((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),'Title',['Top' num2str(i)],'YLabel','Day','Colormap',gray,'CellLabelColor','none','MissingDataColor',[0.6350 0.0780 0.1840]);
        hFig = gcf;
        saveas(gcf,[result_dir '\totalGroupNormalizedTop ' convertStringsToChars(num2str(i))],'png');
        picAddress=[result_dir '\totalGroupNormalizedTop ' convertStringsToChars(num2str(i)) '.png'];
        close all;
        GROUPPlot=groupPlotClusteringFunction(totalGroupNormalizedTop((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),picAddress,experimentPeriod);
        hold on
        text(509,34,[ 'Grouping Time: ' num2str(FlyInGroupDurationSort(i))]);
        hFig = gcf;
        saveas(gcf,[result_dir '\markedTotalGroupNormalizedTop ' convertStringsToChars(num2str(i)) ],'png');
        hold off
    end
end
%%
if bottomNumber>0
    for i = bottomNumber:-1:1
        for count = 1:experimentPeriod
            totalGroupBottom((i-1)*experimentPeriod+count,:)=flyInGroupDurationRead(SortIndex(criteria_n_of_ob-bottomNumber+i),:,count);
            totalGroupBottom((i-1)*experimentPeriod+count,SortIndex(criteria_n_of_ob-bottomNumber+i))=nan;%�����ۤv
            totalGroupNormalizedBottom((i-1)*experimentPeriod+count,:)=(totalGroupBottom((i-1)*experimentPeriod+count,:)-min(totalGroupBottom((i-1)*experimentPeriod+count,:)))./(max(totalGroupBottom((i-1)*experimentPeriod+count,:))-min(totalGroupBottom((i-1)*experimentPeriod+count,:)));
        end
        close all
        totalGroupNormalizedBottomInverse=1-totalGroupNormalizedBottom;
        figure,heatmap(totalGroupNormalizedBottomInverse((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),'Title',['Top' num2str(criteria_n_of_ob-bottomNumber+i)],'YLabel','Day','Colormap',gray,'CellLabelColor','none','MissingDataColor',[0.6350 0.0780 0.1840]);
        saveas(gcf,[result_dir '\totalGroupNormalizedTop ' convertStringsToChars(num2str(criteria_n_of_ob-bottomNumber+i))],'png');
        picAddress=[result_dir '\totalGroupNormalizedTop ' convertStringsToChars(num2str(criteria_n_of_ob-bottomNumber+i)) '.png'];
        close all;
        GROUPPlot=groupPlotClusteringFunction(totalGroupNormalizedBottom((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),picAddress,experimentPeriod);
        hold on
        text(509,34,[ 'Grouping Time: ' num2str(FlyInGroupDurationSort(criteria_n_of_ob-bottomNumber+i))]);
        hFig = gcf;
        saveas(gcf,[result_dir '\markedTotalGroupNormalizedTop ' convertStringsToChars(num2str(criteria_n_of_ob-bottomNumber+i)) ],'png');
        hold off
    end
end
xlswrite([result_dir '\totalGroupBottom.xlsx'],totalGroupBottom);
xlswrite([result_dir '\totalGroupTop.xlsx'],totalGroupTop);
xlswrite([result_dir '\totalGroupNormalizedBottom.xlsx'],totalGroupNormalizedBottom);
xlswrite([result_dir '\totalGroupNormalizedTop.xlsx'],totalGroupNormalizedTop);
