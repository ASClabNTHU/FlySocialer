interact_durationTotal_analysis=zeros(criteria_n_of_ob,criteria_n_of_ob);
suminteract_durationTotal_analysis=zeros(criteria_n_of_ob,criteria_n_of_ob);
interact_durationTotal_analysisRecord=zeros(criteria_n_of_ob,criteria_n_of_ob,experimentPeriod);
for i=1:experimentPeriod
    
    dataX= [ convertStringsToChars(Analy_dir(i)) '\interact_durationTotal_analysis\interact_durationTotal_analysis' (num2str(recordDuration))  '.xls'];
    interact_durationTotal_analysis=xlsread (dataX);
    interact_durationTotal_analysis=interact_durationTotal_analysis';
    suminteract_durationTotal_analysis=interact_durationTotal_analysis+suminteract_durationTotal_analysis;
    
    interact_durationTotal_analysisRecord(:,:,i)=interact_durationTotal_analysis;
end
[interact_durationTotal_analysisSort,SortIndex]=sort(sum(suminteract_durationTotal_analysis,2),'descend'); %�p���h~��

%%
%read array
if topNumber>0
    for i = 1:topNumber
        for count = 1:experimentPeriod
            interact_durationTotal_analysisTop((i-1)*experimentPeriod+count,:)=interact_durationTotal_analysisRecord(SortIndex(i),:,count);
            interact_durationTotal_analysisTop((i-1)*experimentPeriod+count,SortIndex(i))=nan;%�����ۤv
            interact_durationTotal_analysisNormalizedTop((i-1)*experimentPeriod+count,:)=(interact_durationTotal_analysisTop((i-1)*experimentPeriod+count,:)-min(interact_durationTotal_analysisTop((i-1)*experimentPeriod+count,:)))./(max(interact_durationTotal_analysisTop((i-1)*experimentPeriod+count,:))-min(interact_durationTotal_analysisTop((i-1)*experimentPeriod+count,:)));
        end
        close all
        interact_durationTotal_analysisNormalizedTopInverse=1-interact_durationTotal_analysisNormalizedTop;
        heatmap(interact_durationTotal_analysisNormalizedTopInverse((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),'Title',['interact durationTotal analysis Top' num2str(i)],'YLabel','Day','Colormap',gray,'CellLabelColor','none','MissingDataColor',[0.6350 0.0780 0.1840]);
        hFig = gcf;
        %saveas(gcf,[result_dir '\interact_durationTotal_analysisNormalizedTop ' convertStringsToChars(num2str(i))],'png');
        picAddress=[result_dir '\interact_durationTotal_analysisNormalizedTop ' convertStringsToChars(num2str(i)) '.png'];
        close all;
%        GROUPPlot=groupPlotClusteringFunction(interact_durationTotal_analysisNormalizedTop((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),picAddress,experimentPeriod);
        hold on
        text(631,18,[ 'Total Interact times (5 days): ' num2str(interact_durationTotal_analysisSort(i)) 'sec']);
        hFig = gcf;
        %saveas(gcf,[result_dir '\markedInteract_durationTotal_analysisNormalizedTop ' convertStringsToChars(num2str(i)) ],'png');
        hold off
    end
end
%%
if bottomNumber>0
    for i = bottomNumber:-1:1
        for count = 1:experimentPeriod
            interact_durationTotal_analysisBottom((i-1)*experimentPeriod+count,:)=interact_durationTotal_analysisRecord(SortIndex(criteria_n_of_ob-bottomNumber+i),:,count);
            interact_durationTotal_analysisBottom((i-1)*experimentPeriod+count,SortIndex(criteria_n_of_ob-bottomNumber+i))=nan;%�����ۤv
            interact_durationTotal_analysisNormalizedBottom((i-1)*experimentPeriod+count,:)=(interact_durationTotal_analysisBottom((i-1)*experimentPeriod+count,:)-min(interact_durationTotal_analysisBottom((i-1)*experimentPeriod+count,:)))./(max(interact_durationTotal_analysisBottom((i-1)*experimentPeriod+count,:))-min(interact_durationTotal_analysisBottom((i-1)*experimentPeriod+count,:)));
        end
        close all
        interact_durationTotal_analysisNormalizedBottomInverse=1-interact_durationTotal_analysisNormalizedBottom;
        figure,heatmap(interact_durationTotal_analysisNormalizedBottomInverse((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),'Title',['interact durationTotal analysis Top' num2str(criteria_n_of_ob-bottomNumber+i)],'YLabel','Day','Colormap',gray,'CellLabelColor','none','MissingDataColor',[0.6350 0.0780 0.1840]);
        %saveas(gcf,[result_dir '\interact_durationTotal_analysisNormalizedTop ' convertStringsToChars(num2str(criteria_n_of_ob-bottomNumber+i))],'png');
        picAddress=[result_dir '\interact_durationTotal_analysisNormalizedTop ' convertStringsToChars(num2str(criteria_n_of_ob-bottomNumber+i)) '.png'];
        close all;
        %GROUPPlot=groupPlotClusteringFunction(interact_durationTotal_analysisNormalizedBottom((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),picAddress,experimentPeriod);
        hold on
        text(631,18,[ 'Total Interact times (5 days): ' num2str(interact_durationTotal_analysisSort(criteria_n_of_ob-bottomNumber+i)) 'sec']);
        hFig = gcf;
        %saveas(gcf,[result_dir '\markedInteract_durationTotal_analysisNormalizedTop ' convertStringsToChars(num2str(criteria_n_of_ob-bottomNumber+i)) ],'png');
        hold off
    end
end
if bottomNumber >0 
xlswrite([result_dir '\Passiveinteract_durationTotal_analysisBottom.xlsx'],interact_durationTotal_analysisBottom);
xlswrite([result_dir '\Passiveinteract_durationTotal_analysisNormalizedBottom.xlsx'],interact_durationTotal_analysisNormalizedBottom);
end
xlswrite([result_dir '\1Passiveinteract_durationTotal_analysisTop.xlsx'],interact_durationTotal_analysisTop);
str=strsplit(sprintf(',#%d',SortIndex.')  );
out=strjoin(str);
out(1)=[];
xlswrite([result_dir '\1Passiveinteract_durationTotal_analysisTop_order.xlsx'],cellstr(out));
xlswrite([result_dir '\1PassiveInteract_durationTotal_analysisNormalizedTop.xlsx'],interact_durationTotal_analysisNormalizedTop);
batch=sum(interact_durationTotal_analysisTop,2,'omitnan');
for count=1:experimentPeriod:experimentPeriod*criteria_n_of_ob
    finalBatch(:,(count-1)/experimentPeriod+1)=batch(count:count+experimentPeriod-1,1);
end
xlswrite([result_dir '\00PassiveFinalBatch_interact_durationTotal_analysisTop.xlsx'],finalBatch);