sumDistanceEachOther=zeros(criteria_n_of_ob,criteria_n_of_ob);
sumDistanceEachOtherTemp=zeros(criteria_n_of_ob,criteria_n_of_ob);
sumDistanceEachOtherRecord=zeros(criteria_n_of_ob,criteria_n_of_ob,experimentPeriod);
for i=1:experimentPeriod
    for count= 1:recordDuration
        dataX= [ convertStringsToChars(Analy_dir(i)) '\DistanceEachOther\DistanceEachOther' num2str(count) '.xls'];
        DistanceEachOther=xlsread (dataX);
        [m, n]=size(DistanceEachOther);
        DistanceEachOther(:,criteria_n_of_ob+1:n)=[];
        sumDistanceEachOtherTemp=DistanceEachOther+sumDistanceEachOtherTemp;
        sumDistanceEachOther=DistanceEachOther+sumDistanceEachOther;
    end
    
    sumDistanceEachOtherRecord(:,:,i)=sumDistanceEachOtherTemp;
    xlswrite([convertStringsToChars(Analy_dir(i)) '\AverageDistanceEachOtherInMinute.xlsx'],sumDistanceEachOtherTemp./recordDuration);
    sumDistanceEachOtherTemp=zeros(criteria_n_of_ob,criteria_n_of_ob);
    
end
xlswrite([result_dir '\AverageDistanceEachOtherInMinuteInWholeExperimentPeriod.xlsx'],(sumDistanceEachOther./recordDuration./experimentPeriod));
[DistanceEachOtherSort,SortIndex]=sort(sum(sumDistanceEachOther,2)); %�p����~�h

%%
%read array
if topNumber>0
    for i = 1:topNumber
        for count = 1:experimentPeriod
            totalDistanceTop((i-1)*experimentPeriod+count,:)=sumDistanceEachOtherRecord(SortIndex(i),:,count);
            totalDistanceTop((i-1)*experimentPeriod+count,SortIndex(i))=nan;%�����ۤv
            totalDistanceNormalizedTop((i-1)*experimentPeriod+count,:)=(totalDistanceTop((i-1)*experimentPeriod+count,:)-min(totalDistanceTop((i-1)*experimentPeriod+count,:)))./(max(totalDistanceTop((i-1)*experimentPeriod+count,:))-min(totalDistanceTop((i-1)*experimentPeriod+count,:)));
        end
        close all
        totalDistanceNormalizedTopInverse=1-totalDistanceNormalizedTop; %�¥չ��
        heatmap(totalDistanceNormalizedTopInverse((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),'Title',['Distance Shortest Top' num2str(i)],'YLabel','Day','Colormap',gray,'CellLabelColor','none','MissingDataColor',[0.6350 0.0780 0.1840]);
        hFig = gcf;
        saveas(gcf,[result_dir '\totalDistanceNormalizedShortest ' convertStringsToChars(num2str(i))],'png');
        picAddress=[result_dir '\totalDistanceNormalizedShortest ' convertStringsToChars(num2str(i)) '.png'];
        close all;
        GROUPPlot=groupPlotClusteringFunction(totalDistanceNormalizedTop((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),picAddress,experimentPeriod);
              
        hFig = gcf;
        saveas(gcf,[result_dir '\markedTotalDistanceNormalizedShortest ' convertStringsToChars(num2str(i)) ],'png');
    end
end
%%
if bottomNumber>0
    for i = bottomNumber:-1:1
        for count = 1:experimentPeriod
            totalDistanceBottom((i-1)*experimentPeriod+count,:)=sumDistanceEachOtherRecord(SortIndex(criteria_n_of_ob-bottomNumber+i),:,count);
            totalDistanceBottom((i-1)*experimentPeriod+count,SortIndex(criteria_n_of_ob-bottomNumber+i))=nan;%�����ۤv
            totalDistanceNormalizedBottom((i-1)*experimentPeriod+count,:)=(totalDistanceBottom((i-1)*experimentPeriod+count,:)-min(totalDistanceBottom((i-1)*experimentPeriod+count,:)))./(max(totalDistanceBottom((i-1)*experimentPeriod+count,:))-min(totalDistanceBottom((i-1)*experimentPeriod+count,:)));
        end
        close all
        totalDistanceNormalizedBottomInverse=1-totalDistanceNormalizedBottom; %�¥չ��
        figure,heatmap(totalDistanceNormalizedBottomInverse((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),'Title',['Distance Longest Top' num2str(i)],'YLabel','Day','Colormap',gray,'CellLabelColor','none','MissingDataColor',[0.6350 0.0780 0.1840]);
        saveas(gcf,[result_dir '\totalDistanceNormalizedLongest ' convertStringsToChars(num2str(i))],'png');
        picAddress=[result_dir '\totalDistanceNormalizedLongest ' convertStringsToChars(num2str(i)) '.png'];
        close all;
        GROUPPlot=groupPlotClusteringFunction(totalDistanceNormalizedBottom((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),picAddress,experimentPeriod);
        hFig = gcf;
        saveas(gcf,[result_dir '\markedTotalDistanceNormalizedLongest ' convertStringsToChars(num2str(i)) ],'png');
    end
end
if bottomNumber >0 
xlswrite([result_dir '\totalDistanceLongestTop.xlsx'],totalDistanceBottom);
xlswrite([result_dir '\totalNormalizedDistanceLongestTop.xlsx'],totalDistanceNormalizedBottom);
end
xlswrite([result_dir '\totalDistanceShortestTop.xlsx'],totalDistanceTop);
str=strsplit(sprintf(',#%d',SortIndex.')  );
out=strjoin(str);
out(1)=[];
xlswrite([result_dir '\1totalDistanceShortestTop.xlsx'],cellstr(out));
xlswrite([result_dir '\totalNormalizedDistanceShortestTop.xlsx'],totalDistanceNormalizedTop);
batch=sum(totalDistanceTop,2,'omitnan');
for count=1:experimentPeriod:experimentPeriod*criteria_n_of_ob
    finalBatch(:,(count-1)/experimentPeriod+1)=batch(count:count+experimentPeriod-1,1);
end
xlswrite([result_dir '\00finalBatch_totalDistanceTop.xlsx'],finalBatch);
