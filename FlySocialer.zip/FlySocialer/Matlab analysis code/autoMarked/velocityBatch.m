velocityMatrixMeanBatch=zeros(criteria_n_of_ob,experimentPeriod);
velocityTotalMeanBatch=zeros(1,experimentPeriod);

for i=1:experimentPeriod
    
    dataX= [ convertStringsToChars(Analy_dir(i)) '\velocityMatrix.xls'];
    velocityMatrix=xlsread (dataX);
    velocityMatrixMeanBatch(:,i)=sum(velocityMatrix,2)/recordDuration;
    velocityTotalMeanBatch(1,i)=sum(sum(velocityMatrix))/recordDuration/criteria_n_of_ob;
end
    xlswrite([result_dir '\00velocityMatrixMeanBatch.xlsx'],velocityMatrixMeanBatch);
    xlswrite([result_dir '\00velocityTotalMeanBatch.xlsx'],velocityTotalMeanBatch);