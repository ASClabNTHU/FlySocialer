AverageDurationRecord=interact_durationTotal_analysisRecord./interact_analysisRecord;
AverageDurationRecordFiveDays=sum(interact_durationTotal_analysisRecord,3) ./ sum(interact_analysisRecord,3);

[AverageDurationSort,SortIndex]=sort(nansum(AverageDurationRecordFiveDays,2),'descend'); %�p���h~��
AverageDurationSort=AverageDurationSort/10;
%%
%read array
if topNumber>0
    for i = 1:topNumber
        for count = 1:experimentPeriod
            AverageDurationTop((i-1)*experimentPeriod+count,:)=AverageDurationRecord(SortIndex(i),:,count);
            AverageDurationTop((i-1)*experimentPeriod+count,SortIndex(i))=nan;%�����ۤv
            AverageDurationNormalizedTop((i-1)*experimentPeriod+count,:)=(AverageDurationTop((i-1)*experimentPeriod+count,:)-min(AverageDurationTop((i-1)*experimentPeriod+count,:)))./(max(AverageDurationTop((i-1)*experimentPeriod+count,:))-min(AverageDurationTop((i-1)*experimentPeriod+count,:)));
        end
        close all
        AverageDurationNormalizedTopInverse=1-AverageDurationNormalizedTop;
        heatmap(AverageDurationNormalizedTopInverse((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),'Title',['Average Duration Top' num2str(i)],'YLabel','Day','Colormap',gray,'CellLabelColor','none','MissingDataColor',[0.6350 0.0780 0.1840]);
        hFig = gcf;
        saveas(gcf,[result_dir '\AverageDurationNormalizedTop ' convertStringsToChars(num2str(i))],'png');
        picAddress=[result_dir '\AverageDurationNormalizedTop ' convertStringsToChars(num2str(i)) '.png'];
        close all;
        GROUPPlot=groupPlotClusteringFunction(AverageDurationNormalizedTop((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),picAddress,experimentPeriod);
        hold on
        text(631,18,[ 'Average Interaction times (5 days): ' num2str(AverageDurationSort(i)) 'sec']);
        hFig = gcf;
        saveas(gcf,[result_dir '\markedAverageDurationNormalizedTop ' convertStringsToChars(num2str(i)) ],'png');
        hold off
    end
end
%%
if bottomNumber>0
    for i = bottomNumber:-1:1
        for count = 1:experimentPeriod
            AverageDurationBottom((i-1)*experimentPeriod+count,:)=AverageDurationRecord(SortIndex(criteria_n_of_ob-bottomNumber+i),:,count);
            AverageDurationBottom((i-1)*experimentPeriod+count,SortIndex(criteria_n_of_ob-bottomNumber+i))=nan;%�����ۤv
            AverageDurationNormalizedBottom((i-1)*experimentPeriod+count,:)=(AverageDurationBottom((i-1)*experimentPeriod+count,:)-min(AverageDurationBottom((i-1)*experimentPeriod+count,:)))./(max(AverageDurationBottom((i-1)*experimentPeriod+count,:))-min(AverageDurationBottom((i-1)*experimentPeriod+count,:)));
        end
        close all
        AverageDurationNormalizedBottomInverse=1-AverageDurationNormalizedBottom;
        figure,heatmap(AverageDurationNormalizedBottomInverse((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),'Title',['Average Duration Top' num2str(criteria_n_of_ob-bottomNumber+i)],'YLabel','Day','Colormap',gray,'CellLabelColor','none','MissingDataColor',[0.6350 0.0780 0.1840]);
        saveas(gcf,[result_dir '\AverageDurationNormalizedTop ' convertStringsToChars(num2str(criteria_n_of_ob-bottomNumber+i))],'png');
        picAddress=[result_dir '\AverageDurationNormalizedTop ' convertStringsToChars(num2str(criteria_n_of_ob-bottomNumber+i)) '.png'];
        close all;
        GROUPPlot=groupPlotClusteringFunction(AverageDurationNormalizedBottom((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),picAddress,experimentPeriod);
        hold on
        text(631,18,[ 'Average Interaction times (5 days): ' num2str(AverageDurationSort(criteria_n_of_ob-bottomNumber+i)) 'sec']);
        hFig = gcf;
        saveas(gcf,[result_dir '\markedAverageDurationNormalizedTop ' convertStringsToChars(num2str(criteria_n_of_ob-bottomNumber+i)) ],'png');
        hold off
    end
end
if bottomNumber >0 
xlswrite([result_dir '\AverageDurationBottom.xlsx'],AverageDurationBottom);
xlswrite([result_dir '\AverageDurationNormalizedBottom.xlsx'],AverageDurationNormalizedBottom);
end
xlswrite([result_dir '\AverageDurationTop.xlsx'],AverageDurationTop);
str=strsplit(sprintf(',#%d',SortIndex.')  );
out=strjoin(str);
out(1)=[];
xlswrite([result_dir '\1AverageDurationTop_order.xlsx'],cellstr(out));
xlswrite([result_dir '\AverageDurationNormalizedTop.xlsx'],AverageDurationNormalizedTop);
batch=sum(AverageDurationTop,2,'omitnan');
for count=1:experimentPeriod:experimentPeriod*criteria_n_of_ob
    finalBatch(:,(count-1)/experimentPeriod+1)=batch(count:count+experimentPeriod-1,1);
end
xlswrite([result_dir '\00finalBatch_AverageDurationTop.xlsx'],finalBatch);
