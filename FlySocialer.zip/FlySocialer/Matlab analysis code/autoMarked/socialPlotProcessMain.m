clear all
close all
experimentPeriod=5;%����Ѽ�Fake3605Single4
Analy_dir= strings(experimentPeriod,1);
Analy_dir(1) = "Y:\S_DADA_Yang\ASCO\Individuality\Vibration\CantonS_single vs group\20230725\_0725_1_CantonS_0_CantonS_10min_result1";
Analy_dir(2) = "Y:\S_DADA_Yang\ASCO\Individuality\Vibration\CantonS_single vs group\20230725\_0725_2_CantonS_0_CantonS_10min_result1";
Analy_dir(3) = "Y:\S_DADA_Yang\ASCO\Individuality\Vibration\CantonS_single vs group\20230725\_0725_3_CantonS_0_CantonS_10min_result1";
Analy_dir(4) = "Y:\S_DADA_Yang\ASCO\Individuality\Vibration\CantonS_single vs group\20230725\_0725_4_CantonS_0_CantonS_10min_result1";
Analy_dir(5) = "Y:\S_DADA_Yang\ASCO\Individuality\Vibration\CantonS_single vs group\20230725\_0725_5_CantonS_0_CantonS_10min_result1";
%Analy_dir(6) = "C:\20220314\_0314_6_Orco_0_CantonS_result1";

result_dir = 'Y:\S_DADA_Yang\ASCO\Individuality\Vibration\CantonS_single vs group\20230725\Analysis_10min_result1'; 
mkdir(result_dir);
criteria_n_of_ob=10;%����
recordDuration=10;%���R�ɶ�(����)
SingleDistanceThreshold=7*19.5;%���s�Z��7mm*19.5pixel
topNumber=10;
bottomNumber=0;
%%
socialDistancePlotProcessMount;
SocialInteractPlotProcessMount;
SocialInteractDurationPlotProcessMount;
SocialAverageDurationPlotProcessMount;
velocityBatch
passiveSocialInteractPlotProcessMount
passiveSocialInteractDurationPlotProcessMount