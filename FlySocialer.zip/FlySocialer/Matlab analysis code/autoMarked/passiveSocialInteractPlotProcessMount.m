interact_analysis=zeros(criteria_n_of_ob,criteria_n_of_ob);
sumInteract_analysis=zeros(criteria_n_of_ob,criteria_n_of_ob);
interact_analysisRecord=zeros(criteria_n_of_ob,criteria_n_of_ob,experimentPeriod);
for i=1:experimentPeriod
    
    dataX= [ convertStringsToChars(Analy_dir(i)) '\interact_analysis\interact_analysis' (num2str(recordDuration)) '.xls'];
    interact_analysis=xlsread (dataX);
    interact_analysis=interact_analysis';
    sumInteract_analysis=interact_analysis+sumInteract_analysis;
    
    interact_analysisRecord(:,:,i)=interact_analysis;
end
[interact_analysisSort,SortIndex]=sort(sum(sumInteract_analysis,2),'descend'); %�p���h~��

%%
%read array
if topNumber>0
    for i = 1:topNumber
        for count = 1:experimentPeriod
            interact_analysisTop((i-1)*experimentPeriod+count,:)=interact_analysisRecord(SortIndex(i),:,count);
            
            interact_analysisTop((i-1)*experimentPeriod+count,SortIndex(i))=nan;%�����ۤv
            interact_analysisNormalizedTop((i-1)*experimentPeriod+count,:)=(interact_analysisTop((i-1)*experimentPeriod+count,:)-min(interact_analysisTop((i-1)*experimentPeriod+count,:)))./(max(interact_analysisTop((i-1)*experimentPeriod+count,:))-min(interact_analysisTop((i-1)*experimentPeriod+count,:)));
        end
        close all
        interact_analysisNormalizedTopInverse=1-interact_analysisNormalizedTop;
        heatmap(interact_analysisNormalizedTopInverse((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),'Title',['interact analysis Top' num2str(i)],'YLabel','Day','Colormap',gray,'CellLabelColor','none','MissingDataColor',[0.6350 0.0780 0.1840]);
        hFig = gcf;
        %saveas(gcf,[result_dir '\interact_analysisNormalizedTop ' convertStringsToChars(num2str(i))],'png');
        picAddress=[result_dir '\interact_analysisNormalizedTop ' convertStringsToChars(num2str(i)) '.png'];
        close all;
      %  GROUPPlot=groupPlotClusteringFunction(interact_analysisNormalizedTop((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),picAddress,experimentPeriod);
        hold on
      %  text(571,34,[ 'Total Interact Bout (5 days): ' num2str(interact_analysisSort(i))]);
      %  hFig = gcf;
      %  %saveas(gcf,[result_dir '\markedInteract_analysisNormalizedTop ' convertStringsToChars(num2str(i)) ],'png');
        hold off
    end
end
%%
if bottomNumber>0
    for i = bottomNumber:-1:1
        for count = 1:experimentPeriod
            interact_analysisBottom((i-1)*experimentPeriod+count,:)=interact_analysisRecord(SortIndex(criteria_n_of_ob-bottomNumber+i),:,count);
            interact_analysisBottom((i-1)*experimentPeriod+count,SortIndex(criteria_n_of_ob-bottomNumber+i))=nan;%�����ۤv
            interact_analysisNormalizedBottom((i-1)*experimentPeriod+count,:)=(interact_analysisBottom((i-1)*experimentPeriod+count,:)-min(interact_analysisBottom((i-1)*experimentPeriod+count,:)))./(max(interact_analysisBottom((i-1)*experimentPeriod+count,:))-min(interact_analysisBottom((i-1)*experimentPeriod+count,:)));
        end
        close all
        interact_analysisNormalizedBottomInverse=1-interact_analysisNormalizedBottom;
        figure,heatmap(interact_analysisNormalizedBottomInverse((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),'Title',['interact analysis Top' num2str(criteria_n_of_ob-bottomNumber+i)],'YLabel','Day','Colormap',gray,'CellLabelColor','none','MissingDataColor',[0.6350 0.0780 0.1840]);
       % %saveas(gcf,[result_dir '\interact_analysisNormalizedTop ' convertStringsToChars(num2str(criteria_n_of_ob-bottomNumber+i))],'png');
        picAddress=[result_dir '\interact_analysisNormalizedTop ' convertStringsToChars(num2str(criteria_n_of_ob-bottomNumber+i)) '.png'];
        close all;
     %   GROUPPlot=groupPlotClusteringFunction(interact_analysisNormalizedBottom((i-1)*experimentPeriod+1:(i-1)*experimentPeriod+experimentPeriod,:),picAddress,experimentPeriod);
        hold on
        text(571,34,[ 'Total Interact Bout (5 days): ' num2str(interact_analysisSort(criteria_n_of_ob-bottomNumber+i))]);
        hFig = gcf;
    %    %saveas(gcf,[result_dir '\markedInteract_analysisNormalizedTop ' convertStringsToChars(num2str(criteria_n_of_ob-bottomNumber+i)) ],'png');
        hold off
    end
end
if bottomNumber >0 
xlswrite([result_dir '\Passiveinteract_analysisBottom.xlsx'],interact_analysisBottom);
xlswrite([result_dir '\Passiveinteract_analysisNormalizedBottom.xlsx'],interact_analysisNormalizedBottom);
xlswrite([result_dir '\1PassiveIinteract_analysisBottom_order.xlsx'],SortIndex.');
end

xlswrite([result_dir '\Passiveinteract_analysisTop.xlsx'],interact_analysisTop);
xlswrite([result_dir '\Passiveinteract_analysisNormalizedTop.xlsx'],interact_analysisNormalizedTop);
str=strsplit(sprintf(',#%d',SortIndex.')  );
out=strjoin(str);
out(1)=[];
xlswrite([result_dir '\1PassiveInteract_analysisTop_order.xlsx'],cellstr(out));
batch=sum(interact_analysisTop,2,'omitnan');
for count=1:experimentPeriod:experimentPeriod*criteria_n_of_ob
    finalBatch(:,(count-1)/experimentPeriod+1)=batch(count:count+experimentPeriod-1,1);
end
xlswrite([result_dir '\00PassiveFinalBatch_interact_Total_analysisTop.xlsx'],finalBatch);
