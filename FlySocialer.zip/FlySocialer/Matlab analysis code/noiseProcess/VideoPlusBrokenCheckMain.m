clear all
FramesPath = 'C:\Two color light plate\20230719';
videoName = '_0719_pain-Gal4_ChR2_ATR_B5G5_1';
arenaNum='1';
flyNum=10;
background=imread([FramesPath '\back' videoName '.jpg' ]);
load ([FramesPath '\back' videoName '_interest_circle_' arenaNum]);
fps = 20;
recordingFrame=3*20*fps;%30����*60*fps
intervalFrame = 3*20*fps;%10����*60*FPS
interest_circle1=interest_circle;
VideoPlusBrokenCheck;
