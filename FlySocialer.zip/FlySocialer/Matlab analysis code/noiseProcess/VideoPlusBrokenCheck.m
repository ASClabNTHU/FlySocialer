framesPath = [FramesPath '\' videoName '\'];

startFrame = 0;
sq2 = ones(5,5);
if(exist('videoName','file'))
    delete videoName.avi
end
intervalNum=recordingFrame/intervalFrame;
for count = 1:intervalNum
videoTitle=[FramesPath '\' videoName '_' num2str(count)];
aviobj=VideoWriter(videoTitle);
aviobj.FrameRate=fps;

open(aviobj);%Open file for writing video data
disp(['�i�઺���~!']);
for i=(count-1)*intervalFrame:count*intervalFrame
    fileName=sprintf('Image%d',i);
    frames=imread([framesPath,fileName,'.jpg']);
    get_rid_of_rough = noiseProcess(frames,background,sq2,interest_circle);
    writeVideo(aviobj,frames);
    if count*(i+1)~=1
        map=previousRough+get_rid_of_rough;
        label_rough1 = bwconncomp(map.*interest_circle1);
        label_rough2 = bwconncomp(map.*interest_circle2);
         if ((label_rough1.NumObjects > flyNum)+ (label_rough2.NumObjects > flyNum2))>0
             disp(fileName);
         end
    end
    previousRough=get_rid_of_rough;

end
close(aviobj);
disp(['��' num2str(count) '�Ӽv���w�g����!']);
end
disp(['�����Ҧ��v��!']);