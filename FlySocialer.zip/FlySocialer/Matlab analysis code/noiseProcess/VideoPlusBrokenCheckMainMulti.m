clear all
FramesPath = 'C:\CantonS_single vs group\20230801';
videoName = ['_0801_1_CantonS_0_CantonS'];
disp(videoName);
arenaNum='1';
arenaNum2='3';
flyNum=10;%INPUT NUMBER OF FLIES in the corresponding arena.
flyNum2=10;%I NPUT NUMBER OF FLIES in the corresponding arena.
background=imread([FramesPath '\back' videoName '.jpg' ]);
exist arenaNum2
if ans ==0
    load ([FramesPath '\back' videoName '_interest_circle_' arenaNum]);
else
    load ([FramesPath '\back' videoName '_interest_circle_' arenaNum]);
    tempCircle = interest_circle;
    interest_circle1=interest_circle;
    load ([FramesPath '\back' videoName '_interest_circle_' arenaNum2]);
    interest_circle2=interest_circle;
    tempCircle = tempCircle+interest_circle;
    interest_circle=tempCircle;
end
fps = 20;
recordingFrame=10*60*fps;%60����*60*fps
intervalFrame =10*60*fps;%10����*60*FPS
VideoPlusBrokenCheck;