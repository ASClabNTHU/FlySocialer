clear all
FramesPath = 'C:\Users\BRC\Desktop\2021032';
videoName = '_0312_1_single_group1_group2';
disp(videoName);
arenaNum='2';
arenaNum2='3';
arenaNum3='4';
flyNum=3;%INPUT NUMBER OF FLIES in the corresponding arena.
flyNum2=3;%INPUT NUMBER OF FLIES in the corresponding arena.
flyNum3=3;%INPUT NUMBER OF FLIES in the corresponding arena.
background=imread([FramesPath '\back' videoName '.jpg' ]);
exist arenaNum2
if ans ==0
    load ([FramesPath '\back' videoName '_interest_circle_' arenaNum]);
else
    load ([FramesPath '\back' videoName '_interest_circle_' arenaNum]);
    tempCircle = interest_circle;
    interest_circle1=interest_circle;
    load ([FramesPath '\back' videoName '_interest_circle_' arenaNum2]);
    interest_circle2=interest_circle;
    tempCircle = tempCircle+interest_circle;
    interest_circle=tempCircle;
    load ([FramesPath '\back' videoName '_interest_circle_' arenaNum3]);
    interest_circle3=interest_circle;
    tempCircle = tempCircle+interest_circle;
    interest_circle=tempCircle;
end
fps = 20;
recordingFrame=60*60*fps;%30����*60*fps
intervalFrame = 10*60*fps;%10����*60*FPS
VideoPlusBrokenCheckThree;
