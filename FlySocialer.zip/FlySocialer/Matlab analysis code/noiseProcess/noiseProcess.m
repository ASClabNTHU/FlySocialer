function get_rid_of_rough = noiseProcess(source,background_frame,sq2,interest_circle)


rough = imabsdiff(source,background_frame);
binary_rough = im2bw(rough,0.1); %old:0.3
binary_rough2=bwareaopen(binary_rough,150);
kk=imclose(binary_rough2,sq2);
cleaned_rough = imdilate(kk,sq2); 
kk2=imclose(cleaned_rough,sq2);
bb=imfill(kk2,'holes').*interest_circle;
get_rid_of_rough = bwareaopen(bb,150);%robert 800
end