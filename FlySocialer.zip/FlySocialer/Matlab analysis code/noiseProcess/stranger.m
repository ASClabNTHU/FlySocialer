imgDir='C:\20220810\_0810_2_3605_0_3605';

DummyFrame=imread('C:\20220810\back_0810_2_3605_0_3605.jpg');
startFr=1375;
EndFr=1380;

for i=startFr:EndFr
    img=imread([imgDir '\Image' num2str(i) '.jpg']);
    [J,rect]=imcrop(img);
    rect=floor(rect);
    temp=img;
    temp(rect(2):rect(2)+rect(4),rect(1):rect(1)+rect(3),:)=DummyFrame(rect(2):rect(2)+rect(4),rect(1):rect(1)+rect(3),:);
    imwrite(temp,[imgDir '\Image' num2str(i) '.jpg']);
end