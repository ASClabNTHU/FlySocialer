for i=1:12001
    fileName=sprintf('Image%d',i);
    try 
        frames=imread([framesPath,fileName,'.jpg']);
    catch
        imwrite(frames,[framesPath,fileName,'.jpg'])
    end

end