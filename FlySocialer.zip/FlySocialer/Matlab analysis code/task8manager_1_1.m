%%
cd 'C:\Matlab analysis code\sand';
clear all;
close all;
MainPathWay = 'C:\CantonS_single vs group\20230801';
SubPathWay = '_0801_1_CantonS_0_CantonS';           
ResultNum ='1';
recordDuration=10; %錄製時間
img_dir = [MainPathWay '\' SubPathWay];                                        
result_dir = [MainPathWay '\' SubPathWay '_' num2str(recordDuration) 'min_result' ResultNum];             
mkdir(result_dir);     
video_name = [result_dir '\' SubPathWay '_result' ResultNum]; 
criteria_n_of_ob=10;

save_video =0;                                                         
static_background = imread([MainPathWay '\back' SubPathWay '.jpg']);
%static_back_ground = cv.imread('back_canton-s_7days_(3)(5)(15)(20)_0407_jpg.jpg');
load([MainPathWay '\back' SubPathWay '_interest_circle_' ResultNum]);
load ([MainPathWay '\point' ResultNum SubPathWay '.mat']);

computerName='868 490 213';

taskDummy0613_thresh15

onlyInteractionAna_0210318

%%

