%%
%cd 'C:\Matlab analysis code\sand';
clear all;
codeSpace='C:\Matlab analysis code\sand';
fakeSpace='C:\Matlab analysis code\Fake';

close all;
MainPathWay = 'C:\Matlab analysis code\Fake\Eye Paint\FakeSample';
%% 批量製造
BatchSampleStart=1;
BatchSampleEnd=45;
for batchCount=BatchSampleStart:BatchSampleEnd
    cd (fakeSpace);
    SubPathWay = ['Fake'  num2str(batchCount)];
    ResultNum ='1';
    img_dir = [MainPathWay '\' SubPathWay];
    result_dir = [MainPathWay '\' SubPathWay '_result' ResultNum];
    mkdir(result_dir);
    criteria_n_of_ob=10;
    recordDuration=10;
    FakeTrack
    onlyInteractionAna_0210318
end