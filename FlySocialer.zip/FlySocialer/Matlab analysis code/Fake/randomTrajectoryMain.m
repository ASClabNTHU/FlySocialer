                          clear all  %% 批量製造
BatchSampleStart=1;
BatchSampleEnd=45;
% Circle definition
circleOrigin=[520,520];
radius=475;
experimentLength=12002;
back=imread('back_0810_2_3605_0_3605.jpg');
%%
% random model setting
mimicDir='C:\Matlab analysis code\Fake\Eye Paint\mimicFile_EyePained';
for batchCount=BatchSampleStart:BatchSampleEnd
outputDir=['C:\Matlab analysis code\Fake\Eye Paint\FakeSample\Fake' num2str(batchCount)];
OutputNumber=10;%輸出隻數
OutputLength=12002;% unit:frame 輸出的長度
OutputLength=OutputLength+10;
accMax=10;% unit:Pixel/frame^2    每次決定的加速度最大變化量
velocityMax=1000;% unit:Pixel/frame^2    速度最大量
decisionMakingMax=10; %unit:Frames 每次決定方向的最久時機
decisionMakingMin=4; %unit:Frames  每次決定方向的最短時機
mkdir(outputDir);
%%
PlotStart=1;
PlotEnd=OutputLength;

movingModel;%製作模形
randomTrajectory;%點創造
outPutResult
end
