folderContent=dir (mimicDir);
[m n]=size(folderContent);
ModelX=[]; ModelY=[];
for count=3:m
    load([mimicDir '\' folderContent(count).name '\debris\head_point_all_x.mat'] );
    load([mimicDir '\' folderContent(count).name '\debris\head_point_all_y.mat'] );
    ModelX=[ModelX;head_point_all_x(:,1:experimentLength)];
    ModelY=[ModelY;head_point_all_y(:,1:experimentLength)];
end
[m n]=size(ModelX);
pad=zeros(m,1);
tempX=[pad, ModelX];
tempY=[pad, ModelY];
tempXX=[ModelX,pad];
tempYY=[ModelY,pad];
distX=tempX-tempXX;distY=tempY-tempYY;
velocityModel=sqrt(distX.^2+distY.^2);
velocityModel(:,1)=[];velocityModel(:,n)=[];
%%
tempX=[pad, velocityModel];
tempXX=[velocityModel,pad];
VeloX=tempX-tempXX;
AccModel=VeloX;
AccModel(:,1)=[];AccModel(:,n-1)=[];