clear all
close all
experimentPeriod=5;%實驗天數
Analy_dir= strings(experimentPeriod,1);
Analy_dir(1) = 'C:\Users\BRC\Desktop\新增資料夾 (2)\_1215_1_Orco_0_CantonS_result1';
Analy_dir(2) = 'C:\Users\BRC\Desktop\新增資料夾 (2)\_1215_2_Orco_0_CantonS_result1';
Analy_dir(3) = 'C:\Users\BRC\Desktop\新增資料夾 (2)\_1215_3_Orco_0_CantonS_result1';
Analy_dir(4) = 'C:\Users\BRC\Desktop\新增資料夾 (2)\_1215_4_Orco_0_CantonS_result1';
Analy_dir(5) = 'C:\Users\BRC\Desktop\新增資料夾 (2)\_1215_5_Orco_0_CantonS_result1';

ColorLimit=[0,2.5];% 若想控制顏色代表的上下限數值,請輸入[下界,上界]的格式,如[0,100];若否,請輸入[nan,nan];
durationColorLimit=[0,10];% 若想控制顏色代表的上下限數值,請輸入[下界,上界]的格式,如[0,100];若否,請輸入[nan,nan];

myFolders = split(Analy_dir(1),'_');
outputDir=[char(myFolders(1)) '_' char(myFolders(2)) '_' char(myFolders(4)) '_' char(myFolders(5)) '_' char(myFolders(6)) '_' char(myFolders(7)) '_interaction matrix plot\' ];
mkdir(outputDir);
[experimentDuration,n]= size(dir ([ char(Analy_dir(1)) '\interact_analysis']));
experimentDuration=experimentDuration/2-1;
interactDir=[ char(Analy_dir(1)) '\interact_analysis\interact_analysis' num2str(experimentDuration) '.mat' ];
load (interactDir);
[m n]=size(interact_analysis10);
interact_analysis_Accumulate=zeros(m,n);
for count= 1:experimentPeriod
    interactDir=[ char(Analy_dir(count)) '\interact_analysis\interact_analysis' num2str(experimentDuration) '.mat' ];
    load (interactDir)
    interact_analysis_Accumulate=interact_analysis_Accumulate+interact_analysis10;
end
interact_analysis_Means=interact_analysis_Accumulate./experimentPeriod;
%% remove 0
for count = 1:10
    interact_analysis_Means(count,count)=nan;
end
%%plot
h=heatmap(interact_analysis_Means,'Colormap',hot);
h.Title='Interaction';
axp = struct(h);
axp.Axes.XAxisLocation = 'top';
exportgraphics(gcf, [outputDir 'InteractionMatrix.jpg']);
h.CellLabelColor='None';
exportgraphics(gcf, [outputDir 'InteractionMatrix_without data label.jpg']);
%%
if isnan(ColorLimit)==0
h=heatmap(interact_analysis_Means,'Colormap',hot,'ColorLimits',ColorLimit);
h.Title='Interaction duration';
axp = struct(h);
axp.Axes.XAxisLocation = 'top';
exportgraphics(gcf, [outputDir 'InteractionMatrix_' int2str(ColorLimit) '.jpg']);
h.CellLabelColor='None';
exportgraphics(gcf, [outputDir 'InteractionMatrix_without data label_' int2str(ColorLimit) '.jpg']);
end
%%
%% interact duration
for count= 1:experimentPeriod
    interactDuraDir=[ char(Analy_dir(count)) '\interact_durationTotal_analysis\interact_durationTotal_analysis' num2str(experimentDuration) '.mat' ];
    load (interactDuraDir)
    interact_analysis_Accumulate=interact_analysis_Accumulate+interact_durationTotal_analysis10;
end
interact_analysis_Means=interact_analysis_Accumulate./experimentPeriod;
%% remove 0
for count = 1:10
    interact_analysis_Means(count,count)=nan;
end
%%plot
h=heatmap(interact_analysis_Means,'Colormap',hot);
h.Title='Interaction duration';
axp = struct(h);
axp.Axes.XAxisLocation = 'top';
exportgraphics(gcf, [outputDir 'InteractionDurationMatrix.jpg']);
h.CellLabelColor='None';
exportgraphics(gcf, [outputDir 'InteractionDurationMatrix_without data label.jpg']);
%%
if isnan(durationColorLimit)==0
h=heatmap(interact_analysis_Means,'Colormap',hot,'ColorLimits',durationColorLimit );
h.Title='Interaction duration';
axp = struct(h);
axp.Axes.XAxisLocation = 'top';
exportgraphics(gcf, [outputDir 'InteractionDurationMatrix_' int2str(durationColorLimit) '.jpg']);
h.CellLabelColor='None';
exportgraphics(gcf, [outputDir 'InteractionDurationMatrix_without data label_' int2str(durationColorLimit) '.jpg']);
end