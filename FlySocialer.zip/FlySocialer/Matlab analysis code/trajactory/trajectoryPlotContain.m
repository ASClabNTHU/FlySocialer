%% read folder
mkdir(savePath);
filesList =dir(savePath);
%% create folder
[m n]=size(filesList);
m=m-1;%delete . and .. folder
saveDir=[savePath '\' num2str(m)];
mkdir(saveDir);
clear m n
%%
load([AnalDir '\debris\fly_posi_all_x' ]);
load([AnalDir '\debris\fly_posi_all_y' ]);
[mm nn]=size(TrackID);
[m n]=size(fly_posi_all_x);
color = ['#FF0000';'#00FF00';'#0000FF';'#00FFFF';'#FF00FF';	'#FFFF00';'#000000';'#D95319';'#EDB120';'#77AC30'];
switch str2num(BackTitle{2, 1})
    case 1
    back2=imcrop(back,[1,1,1023,1023]);
case 3
    back2=imcrop(back,[1,1025,1023,1023]);
    fly_posi_all_y=fly_posi_all_y-1024;
    otherwise
disp('error area number!')
a=zzz+2;
end
%% calculat distance
disX=fly_posi_all_x(TrackID(1),1:n-1)-fly_posi_all_x(TrackID(2),1:n-1);
disY=fly_posi_all_y(TrackID(1),1:n-1)-fly_posi_all_y(TrackID(2),1:n-1);
dist=sqrt(disX.^2+disY.^2);
interactLabel=dist<interact_dist;
%% calculate interaction Start
MoveSumm=movsum(interactLabel,30,'Endpoints','discard'); 
interactLabelCheck=find(MoveSumm==30);
interactLabelCheckDiff=diff(interactLabelCheck);
interactLabelCheckDiffCheck=find(interactLabelCheckDiff>1);
InteractStart=[interactLabelCheck(1)];
InteractStart=[InteractStart,interactLabelCheck(interactLabelCheckDiffCheck+1)];
%% calculate interaction End
MoveSumm=movsum(flip(interactLabel),30,'Endpoints','discard'); 
interactLabelCheck=find(MoveSumm==30);
interactLabelCheckDiff=diff(interactLabelCheck);
interactLabelCheckDiffCheck=find(interactLabelCheckDiff>1);
InteractEnd=[interactLabelCheck(1)];
InteractEnd=[InteractEnd,interactLabelCheck(interactLabelCheckDiffCheck+1)];
InteractEnd=flip(12000-InteractEnd+1);
[tempM tempN]=size(InteractEnd);
%%
count=1;
for(i=1:tempN)
    imshow(back2); hold on;
    plot(fly_posi_all_x(TrackID(1),InteractStart(i):InteractEnd(i)),fly_posi_all_y(TrackID(1),InteractStart(i):InteractEnd(i)),'color',[color(colorSelection(1),:)],'LineWidth',2);
    plot(fly_posi_all_x(TrackID(2),InteractStart(i):InteractEnd(i)),fly_posi_all_y(TrackID(2),InteractStart(i):InteractEnd(i)),'color',[color(colorSelection(2),:)],'LineWidth',2);
    text(800,20,['Start:' num2str(floor(InteractStart(i)/20/60)) ':' num2str((InteractStart(i)/20)-floor(InteractStart(i)/20/60)*60)],['Color' ],'red','FontSize',14);
    text(800,50,['End:' num2str(floor(InteractEnd(i)/20/60)) ':' num2str((InteractEnd(i)/20)-floor(InteractEnd(i)/20/60)*60)],['Color' ],'red','FontSize',14);
    hold off;
    count=count+1;
    f = gcf;
    exportgraphics(f,[saveDir '\' num2str(count) '.tif'],'Resolution',600)
end
