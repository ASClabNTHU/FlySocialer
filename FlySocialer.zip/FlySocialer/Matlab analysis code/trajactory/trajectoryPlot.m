clear all
AnalDir='C:\20220616\_0616_1_3605_0_3605_result1'; %想要畫的分析資料夾
TrackID=[4;8]; %想要畫的對象編號
colorSelection=[1,3];%想要畫的顏色編號 1:紅R 2:綠G 3.藍B 4.青藍C 5.洋紅M 6.黃Y 7.黑K 8.橘 9.黃人皮膚 10.暗綠
savePath=[AnalDir '_TrajectoryPlot']; %想要畫的分析資料夾
interact_dist = 20000;
%%
FoldersDir = split(AnalDir,'\');
BackTitle = split(FoldersDir{3, 1},'_result');
MainDir=[FoldersDir{1, 1} '\' FoldersDir{2, 1}];

backName=[MainDir '\back' BackTitle{1, 1}  '.jpg'];
back=imread(backName);

trajectoryPlotContain