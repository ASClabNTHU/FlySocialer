%back=imread('C:\Users\BRC\Desktop\20210312_5\back_0312_5_3605_0_0.jpg');
back=back2;
[x,y]=imcrop(back);
back2=back;
back2(y(2):y(2)+y(4),y(1):y(1)+y(3),1)=back(y(2)+50:50+y(2)+y(4),y(1):y(1)+y(3),1);
back2(y(2):y(2)+y(4),y(1):y(1)+y(3),2)=back(y(2)+50:50+y(2)+y(4),y(1):y(1)+y(3),2);
back2(y(2):y(2)+y(4),y(1):y(1)+y(3),3)=back(y(2)+50:50+y(2)+y(4),y(1):y(1)+y(3),3);
 figure,imshow(back2)