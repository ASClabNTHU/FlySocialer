cd 'C:\Matlab analysis code\sand';
clear all;
close all;
interactDurDefinSec=1; %互動時間定義 ex:1sec
interact_dist = 68.25; %互動距離定義 EX:3.5mm*19.5pixel/mm


%%
MainPathWay = 'C:\Users\BRC\Desktop\single vibration';
SubPathWay = '_0215_1_3605_0_3605';   
ResultNum ='1';  
onlyIntractBatchContent
%%
MainPathWay = 'C:\Users\BRC\Desktop\single vibration';
SubPathWay = '_0215_1_3605_0_3605';
ResultNum ='3';  
onlyIntractBatchContent
%%
MainPathWay = 'C:\Users\BRC\Desktop\single vibration';
SubPathWay = '_0217_1_3605_0_3605';   
ResultNum ='1';  
onlyIntractBatchContent
%%
MainPathWay = 'C:\Users\BRC\Desktop\single vibration';
SubPathWay = '_0217_2_3605_0_3605';   
ResultNum ='3';  
onlyIntractBatchContent
%%
MainPathWay = 'C:\Users\BRC\Desktop\single vibration';
SubPathWay = '_0301_3_3605_0_3605';   
ResultNum ='1';  
onlyIntractBatchContent
%%
MainPathWay = 'C:\Users\BRC\Desktop\single vibration';
SubPathWay = '_0301_3_3605_0_3605';   
ResultNum ='3';  
onlyIntractBatchContent
%%
%MainPathWay = 'C:\Users\BRC\Desktop\single vibration';
%SubPathWay = '_0818_4_3605_0_3605';   
%ResultNum ='1';  
%onlyIntractBatchContent
%%
%MainPathWay = 'C:\Users\BRC\Desktop\single vibration';
%SubPathWay = '_0818_4_3605_0_3605';   
%ResultNum ='3';  
%onlyIntractBatchContent
%%
MainPathWay = 'C:\Users\BRC\Desktop\single vibration';
SubPathWay = '_0818_5_3605_0_3605';   
ResultNum ='1';  
onlyIntractBatchContent
%%


    １
%MainPathWay = 'C:\Users\BRC\Desktop\single vibration';
%SubPathWay = '_0818_5_3605_0_3605';   
%ResultNum ='3';  
%onlyIntractBatchContent
