clear all
close all
AnalysisTarget=1;%第幾隻是目標果蠅
criteria_n_of_ob=10; %果蠅數量
experimentDataAmount=5;%實驗檔案總數，需與下列數量一致
Analy_dir= strings(experimentDataAmount,1);
Analy_dir(1) = "D:\Alex\_0717_result2\_0717_1_w1118_w1118_w1118_result2";
Analy_dir(2) = "D:\Alex\_0717_result2\_0717_2_w1118_w1118_w1118_result2";
Analy_dir(3) = "D:\Alex\_0717_result2\_0717_3_w1118_w1118_w1118_result2";
Analy_dir(4) = "D:\Alex\_0717_result2\_0717_4_w1118_w1118_w1118_result2";
Analy_dir(5) = "D:\Alex\_0717_result2\_0717_5_w1118_w1118_w1118_result2";

result_dir = 'D:\Alex\_0717_result2\heatmap';

parameterOrderCalculate