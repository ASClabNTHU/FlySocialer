clear all
img_dir = 'D:\1229heat5';%圖片位置
video_name='D:\1229heat1\1229heat5';%影片儲存位置和檔名
frameQ=20;
nFrames=10*frameQ;%秒數*桭數
save_video =1; 
img_assembly = dir(fullfile(img_dir,'\*.jpg'));

for p = 1:length(img_assembly)
    
    build_img_names{p,1} = img_assembly(p).name;    % 儲存每張影像名稱的cell矩陣
        
end

[sorted_name,INDEX] = sort_nat(build_img_names);    % 使用nature sort


if save_video ==1
    movFile = VideoWriter(video_name,'MPEG-4');
    set(movFile,'FrameRate',frameQ,'Quality',100);
    open(movFile);
end
for i = 1 :nFrames
     source = imread(fullfile(img_dir,sorted_name{i}));
     imshow(source);
      F=getframe(gca);
      writeVideo(movFile,F);
end
if save_video ==1    
    close(movFile);
end

load handel
sound(y,Fs)