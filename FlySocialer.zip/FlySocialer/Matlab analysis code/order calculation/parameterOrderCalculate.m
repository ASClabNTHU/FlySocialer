order=['A' 'B' 'C' 'D' 'E' 'F' 'G' 'H' 'I' 'J' 'K'];
interact_analysis=zeros(criteria_n_of_ob,criteria_n_of_ob);
interact_analysisRecordStatistics=zeros(experimentDataAmount,criteria_n_of_ob);

interact_durationTotal_analysis=zeros(criteria_n_of_ob,criteria_n_of_ob);
interact_durationTotal_analysisRecordStatistics=zeros(experimentDataAmount,criteria_n_of_ob);

%%
%註記欄位
for i=1:experimentDataAmount
    writematrix(['data' num2str(i)],[result_dir '\parameterOrder.xls'],'Sheet','互動次數','Range',['A' num2str((i-1)*2+2)]);
    writematrix('rank' ,[result_dir '\parameterOrder.xls'],'Sheet','互動次數','Range',['A' num2str(i*2+1)]);
    writematrix(['data' num2str(i)],[result_dir '\parameterOrder.xls'],'Sheet','互動總時間','Range',['A' num2str((i-1)*2+2)]);
    writematrix('rank' ,[result_dir '\parameterOrder.xls'],'Sheet','互動總時間','Range',['A' num2str(i*2+1)]);
    writematrix(['data' num2str(i)],[result_dir '\parameterOrder.xls'],'Sheet','平均每次互動時間','Range',['A' num2str((i-1)*2+2)]);
    writematrix('rank' ,[result_dir '\parameterOrder.xls'],'Sheet','平均每次互動時間','Range',['A' num2str(i*2+1)]);
end
writematrix('target' ,[result_dir '\parameterOrder.xls'],'Sheet','互動次數','Range','A1');
writematrix('target' ,[result_dir '\parameterOrder.xls'],'Sheet','互動總時間','Range','A1');
writematrix('target' ,[result_dir '\parameterOrder.xls'],'Sheet','平均每次互動時間','Range','A1');

for i=1:criteria_n_of_ob
    writematrix(num2str(i),[result_dir '\parameterOrder.xls'],'Sheet','互動次數','Range',[order(i+1) '1']);
    writematrix(num2str(i),[result_dir '\parameterOrder.xls'],'Sheet','互動總時間','Range',[order(i+1) '1']);
    writematrix(num2str(i),[result_dir '\parameterOrder.xls'],'Sheet','平均每次互動時間','Range',[order(i+1) '1']);
end
%%
%數據標記 
for i=1:experimentDataAmount
    
    dataX= [ convertStringsToChars(Analy_dir(i)) '\interact_analysis\interact_analysis30.xls'];
    interact_analysis=xlsread (dataX);
    interact_analysisRecordStatistics(i,:)=interact_analysis(AnalysisTarget,:);   
    dataX= [ convertStringsToChars(Analy_dir(i)) '\interact_durationTotal_analysis\interact_durationTotal_analysis30.xls'];
    interact_durationTotal_analysis=xlsread (dataX);
    interact_durationTotal_analysisRecordStatistics(i,:)=interact_durationTotal_analysis(AnalysisTarget,:);
end
AverageDurationRecordStatistics=interact_durationTotal_analysisRecordStatistics./interact_analysisRecordStatistics;

for i=1:experimentDataAmount
    writematrix(interact_analysisRecordStatistics(i,:),[result_dir '\parameterOrder.xls'],'Sheet','互動次數','Range',['B' num2str((i-1)*2+2)]);
    writematrix(interact_durationTotal_analysisRecordStatistics(i,:),[result_dir '\parameterOrder.xls'],'Sheet','互動總時間','Range',['B' num2str((i-1)*2+2)]);
    writematrix(AverageDurationRecordStatistics(i,:),[result_dir '\parameterOrder.xls'],'Sheet','平均每次互動時間','Range',['B' num2str((i-1)*2+2)]);
end

%%
%排名標記
interact_analysisRecordStatistics(:,AnalysisTarget)=nan;
interact_durationTotal_analysisRecordStatistics(:,AnalysisTarget)=nan;

for i=1:experimentDataAmount
    interact_analysisRecordStatisticsUnfold(1,(i-1)*10+1:10*i)=interact_analysisRecordStatistics(i,:);
    interact_durationTotal_analysisRecordStatisticsUnfold(1,(i-1)*10+1:10*i)=interact_durationTotal_analysisRecordStatistics(i,:);
    AverageDurationRecordStatisticsUnfold(1,(i-1)*10+1:10*i)=AverageDurationRecordStatistics(i,:);
end
%interact_analysisRecordStatistics
rank=floor(tiedrank(interact_analysisRecordStatisticsUnfold));
ranksDescUnfold = (max(rank)+1) - rank;
for i=1:experimentDataAmount
    ranksDesc(i,:)=ranksDescUnfold(1,(i-1)*10+1:10*i);
end
for i=1:experimentDataAmount
    writematrix(ranksDesc(i,:),[result_dir '\parameterOrder.xls'],'Sheet','互動次數','Range',['B' num2str((i-1)*2+3)]);
end
%interact_durationTotal_analysisRecordStatistics
rank=floor(tiedrank(interact_durationTotal_analysisRecordStatisticsUnfold));
ranksDescUnfold = (max(rank)+1) - rank;
for i=1:experimentDataAmount
    ranksDesc(i,:)=ranksDescUnfold(1,(i-1)*10+1:10*i);
end
for i=1:experimentDataAmount
    writematrix(ranksDesc(i,:),[result_dir '\parameterOrder.xls'],'Sheet','互動總時間','Range',['B' num2str((i-1)*2+3)]);
end
%AverageDurationRecordStatistics
rank=floor(tiedrank(AverageDurationRecordStatisticsUnfold));
ranksDescUnfold = (max(rank)+1) - rank;
for i=1:experimentDataAmount
    ranksDesc(i,:)=ranksDescUnfold(1,(i-1)*10+1:10*i);
end
for i=1:experimentDataAmount
    writematrix(ranksDesc(i,:),[result_dir '\parameterOrder.xls'],'Sheet','平均每次互動時間','Range',['B' num2str((i-1)*2+3)]);
end

%%
Excel = actxserver('excel.application');

WB = Excel.Workbooks.Open(fullfile([result_dir '\parameterOrder.xls']),0,false);
for i=1:2:experimentDataAmount
    WB.Worksheets.Item(1).Range(['A' num2str((i-1)*2+2) ':K' num2str((i-1)*2+3) ]).Interior.ColorIndex = 15;
    WB.Worksheets.Item(2).Range(['A' num2str((i-1)*2+2) ':K' num2str((i-1)*2+3) ]).Interior.ColorIndex = 15;
    WB.Worksheets.Item(3).Range(['A' num2str((i-1)*2+2) ':K' num2str((i-1)*2+3) ]).Interior.ColorIndex = 15;
end
WB.Worksheets.Item(1).Range([order(AnalysisTarget+1) '1:' order(AnalysisTarget+1) '11']).Interior.ColorIndex = 3;
WB.Worksheets.Item(2).Range([order(AnalysisTarget+1) '1:' order(AnalysisTarget+1) '11']).Interior.ColorIndex = 3;
WB.Worksheets.Item(3).Range([order(AnalysisTarget+1) '1:' order(AnalysisTarget+1) '11']).Interior.ColorIndex = 3;
WB.Save();
WB.Close();
Excel.Quit();
