%%
cd 'C:\Matlab analysis code\sand';
clear all;
close all;
MainPathWay = 'C:\Heat plate\w1118 38C positive light source';
SubPathWay = '_0612_1_w1118(墊高)';           
ResultNum ='1';
img_dir = [MainPathWay '\' SubPathWay];                                        
result_dir = [MainPathWay '\' SubPathWay '_result' ResultNum];             
mkdir(result_dir);     
video_name = [result_dir '\' SubPathWay '_result' ResultNum]; 
criteria_n_of_ob=10;
recordDuration=2;
save_video =1;                                                         
static_background = imread([MainPathWay '\back' SubPathWay '.jpg']);
%static_back_ground = cv.imread('back_canton-s_7days_(3)(5)(15)(20)_0407_jpg.jpg');
load([MainPathWay '\back' SubPathWay '_interest_circle_' ResultNum]);
load ([MainPathWay '\point' ResultNum SubPathWay '.mat']);
computerName='868 490 213';

taskDummy0613_thresh15

onlyInteractionAna_0210318

%%

