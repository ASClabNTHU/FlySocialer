                                    
result_dir = [MainPathWay '\' SubPathWay '_result' ResultNum '_InteractDif=' num2str(interactDurDefinSec) 'sec;' num2str(interact_dist/19.5) 'mm'];             
mkdir(result_dir);     
recordDuration=10;

interactDurDefinFrame=interactDurDefinSec*20;
onlyIntractProcess
onlyInteractionAna_0210318
AverageDuration=sum(totalInteractDurationTotalAnalysis)/sum(totalInteractAnalysis);
xlswrite([result_dir '\totalInteractDurationTotalAnalysis.xlsx'],totalInteractDurationTotalAnalysis');
velocity = velocityCaulateInterval1_velocityMatrix_0908(recordDuration,analysis_freq_frame, criteria_n_of_ob,fly_posi_all_x,fly_posi_all_y,velocityFolder,result_dir);
accelaration0908;
averageDuration=sum(totalInteractDurationTotalAnalysis)/sum(totalInteractAnalysis);
xlswrite([result_dir '\averageDuration.xlsx'],averageDuration');