frames = [1,2,3,4,5,6,7,8,9,10,11,12];
numFrames=10;
sum=0;
skipCount=0;
countUP=0;
i=1;
while i < numFrames+1
    
    if i~=9
        a=frames(i);
        sum=sum+a;
    else
        for count=i:numFrames-1
            frames(1,count)=frames(1,count+1);
        end
        skipCount=skipCount+1;
        skipJudge=-1;
        numFrames=numFrames+1;
    end
    
i=i+1;
end