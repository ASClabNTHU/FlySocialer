function [headPoint,head_angle,credibility,tempDistanceRecord]=head_orientation_find_body_beta2(get_rid_of_rough,orientation,source,pixelidxlists,fly_posi,RGB_range,major_axis,headPoint)
%color = ['r';'g';'b';'m';'c';'k';'y';];
 %   marker = ['+';'o';'p';'*';'<';'x';'.';'v';'d';'s';'>';'^'];


[M, N]=size(source);
%hsvsource=rgb2hsv(source);
%color_obj = double(hsvsource(:,:,2)).*double(get_rid_of_rough);
color_obj = double(rgb2hsv_fast(source,'','S')).*double(get_rid_of_rough);
low_saturation = find(color_obj>RGB_range(3,1));

ss.Connectivity = 8;
ss.ImageSize = [M N];
ss.NumObjects = size(pixelidxlists,1);

for i = 1:size(pixelidxlists,1)

    new_PixelIdxList = pixelidxlists{i}(ismembc(pixelidxlists{i},low_saturation));
    ss.PixelIdxList{1,i} = new_PixelIdxList';
    
end
    info = regionprops(ss,'Centroid');
    tail_c = cat(1, info.Centroid);

%tail_v = tail_c-fly_posi;
%orien_v = [cosd(orientation) -sind(orientation)];
distanceC=tail_c-fly_posi;
tempDistanceRecord(:,1)=sqrt(distanceC(:,1).^2+distanceC(:,2).^2);
headX1 = fly_posi(:,1)+major_axis(:,1)/2 .* cos(-orientation(:,1)/180*pi);
headY1 = fly_posi(:,2)+major_axis(:,1)/2 .* sin(-orientation(:,1)/180*pi);

headX2 = fly_posi(:,1)+major_axis(:,1)/2 .* cos((-orientation(:,1)+180)/180*pi);
headY2 = fly_posi(:,2)+major_axis(:,1)/2 .* sin((-orientation(:,1)+180)/180*pi);

for p =1:size(tail_c,1)
    a=[headX1(p,1) headY1(p,1); headX2(p,1) headY2(p,1)];
    [distance, ind]=pdist2(a,tail_c(p,:),'euclidean','Smallest',1);
    headPoint(p,:)=a(ind,:);
    credibility(p,1)=min(distance)> 5;
    %tempDistanceRecord(p,1)=min(distance);
    head_angle(p,1)=orientation(p,1)+(ind-1)*180;
    %hold on
     %   plot([fly_posi(p,1),fly_posi(p,1)+major_axis(p,1)/2*cos(-head_angle(p,1)/180*pi)],[fly_posi(p,2),fly_posi(p,2)+major_axis(p,1)/2*sin(-head_angle(p,1)/180*pi)],color(mod(p,7)+1),'LineWidth',3)
end
%{
s  = regionprops(get_rid_of_rough,'ConvexImage','BoundingBox');
boundingBox= cat(1, s.BoundingBox);
z=zeros(2048,2048);
[m n]=size(boundingBox);
for i=1:m
   
    z(boundingBox(i,2):boundingBox(i,2)+boundingBox(i,4)-1,boundingBox(i,1):boundingBox(i,1)+boundingBox(i,3)-1)=s(i, 1).ConvexImage;
end
z=z>0;
z=z-get_rid_of_rough;
indi_flyposi_frame_info = regionprops(z,  'PixelIdxList');
               for p = 1:20
            pixelidxlists{p,1} = (indi_flyposi_frame_info(p).PixelIdxList)';
        end

low_saturation = find(z>0);
for i = 1:size(pixelidxlists,1)

    new_PixelIdxList = pixelidxlists{i}(ismembc(pixelidxlists{i},low_saturation));
    ss.PixelIdxList{1,i} = new_PixelIdxList';
    
end
    info = regionprops(ss,'Centroid');
    tail_c = cat(1, info.Centroid);
    
for p =1:size(tail_c,1)
    a=[headX1(p,1) headY1(p,1); headX2(p,1) headY2(p,1)];
    [distance, ind]=pdist2(a,tail_c(p,:),'euclidean','Largest',1);
    headPointSecondChoice(p,:)=a(ind,:);
    %credibility(p,1)=min(distance)> 5;
    %tempDistanceRecord(p,1)=min(distance);
    head_angle_SecondChoice(p,1)=orientation(p,1)+(ind-1)*180;
    
end
%%
%}


end