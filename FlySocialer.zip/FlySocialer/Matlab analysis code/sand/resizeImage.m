
clear all;
close all;
img_dir = 'C:\20210906\_0906_1_3605_0_3605';   %input the file path of images folder
result_dir = 'C:\20210906\_0906_1_3605_0_3605_resize';
mkdir(result_dir);

%%    reading image 
img_assembly = dir(fullfile(img_dir,'\*.jpg'));
for p = 1:length(img_assembly)
    build_img_names{p,1} = img_assembly(p).name;   
end
[sorted_name,INDEX] = sort_nat(build_img_names);    % nature sorting
nFrames = length(img_assembly); 
for i = 1 : nFrames     
    source = imread(fullfile(img_dir,sorted_name{i}));
    b=imresize(source,2048/1200);
    imwrite(b,(fullfile(result_dir,sorted_name{i})));
end