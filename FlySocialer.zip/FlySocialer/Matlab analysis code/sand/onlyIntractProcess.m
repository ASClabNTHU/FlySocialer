data_dir = [MainPathWay '\' SubPathWay '_result' ResultNum ];  
load([data_dir '\debris\fly_posi_all_x' ]);
load([data_dir '\debris\fly_posi_all_y' ]);
load([data_dir '\debris\head_angle_all' ]);
load([data_dir '\debris\v_vector_all_1' ]);
load([data_dir '\debris\v_vector_all_2' ]);

totalInteractAnalysis=zeros(recordDuration,1);
totalInteractDurationTotalAnalysis=zeros(recordDuration,1);
tempInteractAnalysis=0;
preInteractAnalysis=0;
tempInteractDurationTotalAnalysis=0;
preInteractDurationTotalAnalysis=0;
analysis_freq=1;
analysis_freq_frame=analysis_freq*60*20;
mkdir([result_dir '\DistanceEachOther' ]);
DistanceEachOtherFolder=[result_dir '\DistanceEachOther'];
mkdir([result_dir '\interact_analysis' ]);
interact_analysisFolder=[result_dir '\interact_analysis'];
mkdir([result_dir '\interact_durationTotal_analysis' ]);
interact_durationTotal_analysisFolder=[result_dir '\interact_durationTotal_analysis'];
mkdir([result_dir '\velocity' ]);
velocityFolder=[result_dir '\velocity' ];
mkdir([result_dir '\debris' ]);
debrisFolder=[result_dir '\debris' ];
[criteria_n_of_ob,nFrames]=size(fly_posi_all_x);
duration_sign = zeros(criteria_n_of_ob,criteria_n_of_ob);  
v_vector = [];  
non_touch_record = zeros(criteria_n_of_ob,criteria_n_of_ob);          
inter_count = zeros(criteria_n_of_ob,criteria_n_of_ob); 
interTimeCount= zeros(criteria_n_of_ob,criteria_n_of_ob);  
duration_frame=interactDurDefinFrame;

for i = 1 : nFrames
    fly_posi=[fly_posi_all_x(:,i),fly_posi_all_y(:,i)];
    centroids=fly_posi;

    v_vector1=v_vector_all_1(:,i);
    v_vector2=v_vector_all_2(:,i);
    v_vector(:,1)=v_vector1;
    v_vector(:,2)=v_vector2;
    if i>1
        [non_touch_record, duration_sign, inter_count, interTimeCount] = interaction_record(fly_posi, centroids, interact_dist, criteria_n_of_ob, non_touch_record, v_vector, head_angle_all(:,i), duration_frame, duration_sign, inter_count, interTimeCount);
    end
    if mod(i,analysis_freq_frame)==0

        m = i/analysis_freq_frame*analysis_freq;
        eval(['interact_analysis',num2str(m),'=non_touch_record']);
        save(fullfile(interact_analysisFolder,['interact_analysis'  int2str(m) '.mat']),['interact_analysis'  int2str(m)]);
        xlswrite([interact_analysisFolder '\interact_analysis' int2str(m) '.xls'],non_touch_record);

        %accumulationInteractionTimes=accumulationInteractionTimes+interact_analysis;

        durationBuffer=interTimeCount+30.*non_touch_record;
        durationBuffer=durationBuffer/20;
        eval(['interact_durationTotal_analysis',num2str(m),'=durationBuffer']);
        save(fullfile(interact_durationTotal_analysisFolder,['interact_durationTotal_analysis'  int2str(m) '.mat']),['interact_durationTotal_analysis'  int2str(m)]);
        xlswrite([interact_durationTotal_analysisFolder '\interact_durationTotal_analysis' int2str(m) '.xls'],durationBuffer);

        %%%%%%
        tempInteractAnalysis=sum(sum(non_touch_record));
        tempInteractDurationTotalAnalysis=sum(sum(durationBuffer));
        totalInteractAnalysis(m,1)=tempInteractAnalysis-preInteractAnalysis;
        totalInteractDurationTotalAnalysis(m,1)=tempInteractDurationTotalAnalysis-preInteractDurationTotalAnalysis;
        preInteractAnalysis=tempInteractAnalysis;
        preInteractDurationTotalAnalysis=tempInteractDurationTotalAnalysis;
        %%%%%%
    end

end
