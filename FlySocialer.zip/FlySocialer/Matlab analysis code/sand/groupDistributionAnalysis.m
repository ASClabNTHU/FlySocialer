% clear all
% dataDir='E:\YuZnUsefulResult\_0330_3_w1118\_0330_3_w1118_2u_CS_result1';
load ([ dataDir '\gangIndexDeletedCouple.mat' ]);
load ([ dataDir '\debris\fly_posi_all_x.mat' ])
load ([ dataDir '\debris\fly_posi_all_y.mat' ])
 A = xlsread([ dataDir '\flyInGroupDurationTotal_3up.xlsx' ]);
 A=A*20;
positionX = zeros(10,1);
positionY = zeros(10,1);
groupDivide = zeros(10,1);
oneTemp=ones(10,1);
[m n]=size(gangIndexDeletedCouple);
groupEdge=zeros(m,n);
groupCore=zeros(m,n);
for i=1:n
    if max(gangIndexDeletedCouple(:,i))>0
        C = unique(gangIndexDeletedCouple(:,i));
        C = nonzeros(C);
        C = sort(C);
        [M N]=size(C);
        for count = 1:M
            positionX(gangIndexDeletedCouple(:,i)==C(count),1)=fly_posi_all_x(gangIndexDeletedCouple(:,i)==C(count),i);
            positionY(gangIndexDeletedCouple(:,i)==C(count),1)=fly_posi_all_y(gangIndexDeletedCouple(:,i)==C(count),i);
            groupDivide(gangIndexDeletedCouple(:,i)==C(count),1)=oneTemp(gangIndexDeletedCouple(:,i)==C(count));
            groupCenter(1)=mean(positionX(positionX~=0));
            groupCenter(2)=mean(positionY(positionY~=0));
            diff(:,1) = (positionX-groupCenter(1)).*groupDivide;
            diff(:,2) = (positionY-groupCenter(2)).*groupDivide;
            distance = sqrt(diff(:,1).^2+diff(:,2).^2);
            maxDistance=max(distance);
            groupEdge(distance>maxDistance*0.7,i)=1;
            temp=distance<maxDistance*0.3;
            temp2=distance~=0;
            groupCore(:,i)=temp.*temp2;
        end
    end
    positionX = zeros(10,1);
    positionY = zeros(10,1);
    groupDivide = zeros(10,1);
end
sumGroupEdge=sum(groupEdge,2);
sumGroupCore=sum(groupCore,2);
sumGroupEdgeNormalized=sumGroupEdge./A;
sumGroupCoreNormalized=sumGroupCore./A;
save([ dataDir '\debris\totalGroupEdge.mat'],'groupEdge');
save([ dataDir '\debris\totalGroupCore.mat'],'groupCore');
save([ dataDir '\groupEdge.mat'],'sumGroupEdge');
save([ dataDir '\groupCore.mat'],'sumGroupCore');
writematrix(sumGroupCore,[dataDir '\sumGroupCore.xlsx'])
writematrix(sumGroupEdge,[dataDir '\sumGroupEdge.xlsx'])
writematrix(sumGroupCoreNormalized,[dataDir '\sumGroupCoreNormalized.xlsx'])
writematrix(sumGroupEdgeNormalized,[dataDir '\sumGroupEdgeNormalized.xlsx'])