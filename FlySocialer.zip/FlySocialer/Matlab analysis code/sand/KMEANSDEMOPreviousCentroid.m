load C:\TEST\KMEANS\point2_0202_5_10fly_0_6fly.mat
previous_centroid=previous_centroid2;
load C:\TEST\KMEANS\get_rid_of_rough3.mat
zoom=zeros(100,130);
zoom(:,:)=get_rid_of_rough(930:930+99,1450:1450+129);

imwrite(zoom,'C:\TEST\KMEANS\zoomBW.tiff');
[y,x] = find(get_rid_of_rough);
datapoint = [x y];
for k=1:10

[idx,ctrs] = kmeans(datapoint,2,'start',previous_centroid,'MaxIter',k);
KMEANSSHOW
ctrs=round(ctrs);
zoom=zeros(130,100);
zoom(:,:,1)=gx(1450:1450+129,930:930+99,1);
zoom(:,:,2)=gx(1450:1450+129,930:930+99,2);
zoom(:,:,3)=gx(1450:1450+129,930:930+99,3);
%figure,imshow(zoom)
[idx,ctrs] = kmeans(datapoint,2,'start',previous_centroid,'MaxIter',k-1);
ctrs=round(ctrs);
for xx=-10:10
zoom(ctrs(1,1)-1450+xx,ctrs(1,2)-930,:)=1;
end
for xx=-10:10
zoom(ctrs(1,1)-1450,ctrs(1,2)-930+xx,:)=1;
end
for xx=-10:10
zoom(ctrs(2,1)-1450+xx,ctrs(2,2)-930,:)=1;
end
for xx=-10:10
zoom(ctrs(2,1)-1450,ctrs(2,2)-930+xx,:)=1;
end
%figure,imshow(zoom)
imwrite(zoom,['C:\TEST\KMEANS\zoom' num2str(k) '.tiff']);
end