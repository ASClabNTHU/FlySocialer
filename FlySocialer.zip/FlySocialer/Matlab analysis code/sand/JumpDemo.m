clear all
result_dir = 'Z:\Pain project\Heat plate\PRS\5 day\_0927_1_CantonS_7dayCL_Naive_38C_3min_1_1min_result1';             
                                                      
load ([result_dir '\debris\fly_posi_all_x.mat']);
load ([result_dir '\debris\fly_posi_all_y.mat']);
[m n]= size(fly_posi_all_x);
%load ([MainPathWay '\' SubPathWay '_result' ResultNum '\debris\velocityDiff.mat']);
%% 速度計算

zeroPad=zeros(m,1);
%X軸
padX=[zeroPad fly_posi_all_x];
diffX=padX-[fly_posi_all_x zeroPad];
%Y軸
padY=[zeroPad fly_posi_all_y];
diffY=padY-[fly_posi_all_y zeroPad];
VelocityWhole=sqrt(diffX.^2+diffY.^2);
JumpingDistance=75
JumpDetect=sum(sum(VelocityWhole>(JumpingDistance/19*19.5))); %跳躍門檻
JumpDetect=JumpDetect-2*m;
disp ([': Jumping times:' num2str(JumpDetect)])
FileOutput=fopen( [result_dir '\Jumping' num2str(JumpingDistance) '.txt'],'w');
fprintf(FileOutput,'%d',JumpDetect);
fclose(FileOutput);

Jumpinglobal=VelocityWhole>(JumpingDistance/19*19.5);
Jumpinglobal(:,1)=0; Jumpinglobal(:,end-1)=0;
Jumpinglobal=movsum(Jumpinglobal,5); %前後總共多少張當作同次，11代表是(11-1)/2=5，即前後各五張的意思
Jumpinglobal=Jumpinglobal>0;
Jumpinglobal=diff(Jumpinglobal)<0;
Jumpinglobal=sum(sum(Jumpinglobal));
disp ([': Jumping global :' num2str(Jumpinglobal)])
FileOutput=fopen( [result_dir '\Jumping Global' num2str(JumpingDistance) '.txt'],'w');
fprintf(FileOutput,'%d',Jumpinglobal);
fclose(FileOutput);

%{
img_assembly = dir(fullfile(img_dir,'\*.jpg'));

for p = 1:length(img_assembly)
    
    build_img_names{p,1} = img_assembly(p).name;    % 儲存每張影像名稱的cell矩陣
        
end

[sorted_name,INDEX] = sort_nat(build_img_names);    % 使用nature sort

nFrames = length(img_assembly);    % frame的數量
%% 製作影片

if save_video ==1
    movFile = VideoWriter(video_name,'MPEG-4');
    set(movFile,'FrameRate',60,'Quality',100);
    open(movFile);
end
%%

for i = 1 : N     % build the object-only image & tract object

    source = imread(fullfile(img_dir,sorted_name{i}));
    imshow(source);
    hold on
    plot(fly_posi_all_x(:,i),fly_posi_all_y(:,i),'O');
    plot(fly_posi_all_x(:,i).*JumpDetect(:,i+1),fly_posi_all_y(:,i).*JumpDetect(:,i+1),'rO');
    text(400,400,num2str(i),'FontSize',30)
    F=getframe;
    hold off
    writeVideo(movFile,F);

end
if save_video ==1    
    close(movFile);
end
%}