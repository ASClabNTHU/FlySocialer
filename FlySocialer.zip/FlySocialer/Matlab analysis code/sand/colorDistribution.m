clear all
result_dir = 'C:\20230831\_0831_Gr5a_ReaChR_noATR_G5Y10_1_3min_result1';    %要改          
back=imread('C:\20230831\back_0831_Gr5a_ReaChR_noATR_G5Y10_1.jpg');    %要改   
load ('C:\20230831\back_0831_Gr5a_ReaChR_noATR_G5Y10_1_interest_circle_1.mat')   %要改   
load ([result_dir '\debris\fly_posi_all_x.mat']);
load ([result_dir '\debris\fly_posi_all_y.mat']);
[xxx yyy]=find(fly_posi_all_x==0);
C = unique(yyy);
[m n]= size(C);
for i =m:-1:1
    fly_posi_all_x(:,C(i))=[];
    fly_posi_all_y(:,C(i))=[];
end

%% 顏色分布
%{
sq = ones(3,3);
back2=back;
back(:,:,1)=back(:,:,1).*uint8(interest_circle);
back(:,:,2)=back(:,:,2).*uint8(interest_circle);
back(:,:,3)=back(:,:,3).*uint8(interest_circle);
%% %green zone
G = graythresh(back(:,:,2));
Gbw = imbinarize(back(:,:,2),G);
GbwFill=imfill(Gbw,'holes');
GbwFill = imdilate(GbwFill,sq);
GbwFill = imerode(GbwFill,sq); 
GbwFill=bwareaopen(GbwFill,150);
GbwEdge=edge(GbwFill);
back3=back2;
back3(:,:,2)=back3(:,:,2)+uint8(GbwEdge).*255;
%% %blue zone
B = graythresh(back(:,:,3));
Bbw = imbinarize(back(:,:,3),G);
BbwFill=imfill(Bbw,'holes');
BbwFill = imdilate(BbwFill,sq);
BbwFill = imerode(BbwFill,sq); 
BbwFill=bwareaopen(BbwFill,150);
BbwEdge=edge(BbwFill);

back3(:,:,3)=back3(:,:,3)+uint8(BbwEdge).*255;
figure,imshow(back3)
%}
%% 分布
[xx yy]=find(interest_circle>0);
center=[mean(xx) mean(yy)];
distCenterX=fly_posi_all_x-center(1,1);
distCenterY=fly_posi_all_y-center(1,2);
ZoneDistribution=distCenterX.*distCenterY;
ZoneDistribution=ZoneDistribution>0;
[m n]= size(distCenterX);
distributionTime=zeros(2,floor(n/1200));
for i=1:floor(n/1200)
    distributionTime(1,i)=sum(sum(ZoneDistribution(:,(i-1)*1200+1:i*1200)));
    distributionTime(2,i)=1200*m-distributionTime(1,i);
end
xlswrite([result_dir '\distributionTimeB1G2xTime.xlsx'],distributionTime');
xlswrite([result_dir '\ZoneDistributionB1G0.xlsx'],ZoneDistribution');
